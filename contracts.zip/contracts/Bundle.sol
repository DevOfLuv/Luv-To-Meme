// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {VolumeAsk, IERC20, SafeERC20} from "./utils/VolumeAsk.sol";

interface IWETH {
    function withdraw(uint wad) external;
}

contract Bundle is VolumeAsk {
    using SafeERC20 for IERC20;



    constructor() {}

    /**
     * @dev Bundles transactions.
     * 
     * @param token The token to bundle.
     * @param to_ The address to send the bundled transactions to.
     * @param totalAmount The total amount of tokens to bundle.
     * @param iMax The maximum number of transactions to bundle.
     * 
     */
    function bundleTxn(address token, address to_, uint totalAmount, uint iMax) external {
        IERC20(token).transferFrom(msg.sender, address(this), totalAmount);
        for (uint i = 0; i < iMax; i++) {
            IERC20(token).transfer(to_, totalAmount / iMax);
        }
    }

    /**
     * @dev Changes the openForAll state.
     * 
     * @param openForAll_ The new openForAll state.
     */
    function changeOpenForAll(bool openForAll_) external onlyOwner {
        openForAll = openForAll_;
        emit OpenForAll(openForAll_);
    }

    /**
     * @dev Disperses tokens.
     * 
     * @param token The token to disperse.
     * @param toArray_ The addresses to send the dispersed tokens to.
     * @param amountsArray_ The amounts of tokens to send to each address.
     * @param totalAmount The total amount of tokens to disperse.
     * 
     * NOTE: The 'toArray_' and 'amountsArray_' must be the same length.
     *       The total amount of tokens to disperse must be greater than or equal to the sum of the amounts in 'amountsArray_'.
     */
    function disperse(
        address token,
        address[] memory toArray_,
        uint[] memory amountsArray_,
        uint totalAmount
    ) external nonReentrant {
        require(
            toArray_.length == amountsArray_.length,
            "Arrays must be the same length"
        );
        IERC20(token).safeTransferFrom(msg.sender, address(this), totalAmount);
        uint safetyCheck = 0;
        for (uint i = 0; i < toArray_.length; i++) {
            safetyCheck += amountsArray_[i];
            IERC20(token).safeTransfer(toArray_[i], amountsArray_[i]);
        }
        require(safetyCheck == totalAmount, "Total amount mismatch");
    }

    /**
     * @dev Bundles swaps.
     * 
     * @param token0 The first token to swap.
     * @param token1 The second token to swap.
     * @param amount The amount of tokens to swap.
     * 
     * NOTE: The amount of tokens to swap must be greater than 0.
     */
    function bundleSwapERC(
        address token0,
        address token1,
        uint amount,
        uint iMax
    ) external isOpenForAll {
        uint balanceBefore = IERC20(token0).balanceOf(address(this));
        
        IERC20(token0).transferFrom(msg.sender, address(this), amount);

        IERC20(token0).approve(address(uniswapV2Router), ~uint256(0));
        IERC20(token1).approve(address(uniswapV2Router), ~uint256(0));

        address[] memory path0 = new address[](2);
        path0[0] = token0;
        path0[1] = token1;

        address[] memory path1 = new address[](2);
        path1[0] = token1;
        path1[1] = token0;

        uint bal0;
        uint bal1;


        for (uint i = 0; i < iMax; i++) {
            uniswapV2Router
                .swapExactTokensForTokensSupportingFeeOnTransferTokens(
                    bal0,
                    0,
                    path0,
                    address(this),
                    block.timestamp
                );

            bal1 = IERC20(token1).balanceOf(address(this));

            uniswapV2Router
                .swapExactTokensForTokensSupportingFeeOnTransferTokens(
                    bal1,
                    0,
                    path1,
                    address(this),
                    block.timestamp
                );
            bal0 = IERC20(token0).balanceOf(address(this)) - balanceBefore;
        }

        uint balanceAfter = IERC20(token0).balanceOf(address(this));

        IERC20(token0).transfer(msg.sender, balanceAfter - balanceBefore);

        IERC20(token0).approve(address(uniswapV2Router), 0);
        IERC20(token1).approve(address(uniswapV2Router), 0);
    }

    function bundleSwap(address token0, uint iMax) external payable isOpenForAll {
        uint amount = msg.value;

        IERC20(token0).approve(address(uniswapV2Router), ~uint256(0));

        address[] memory path0 = new address[](2);
        path0[0] = WETH;
        path0[1] = token0;

        address[] memory path1 = new address[](2);
        path1[0] = token0;
        path1[1] = WETH;

        
        uint balanceBefore = address(this).balance;
        for (uint i = 0; i < iMax; i++) {

            uniswapV2Router.swapExactETHForTokens{value: amount}(
                0,
                path0,
                address(this),
                block.timestamp
            );

            uint bal1 = IERC20(token0).balanceOf(address(this));

            uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(
                bal1,
                0,
                path1,
                address(this),
                block.timestamp
            );
            amount = address(this).balance - balanceBefore;
        }
        IERC20(token0).approve(address(uniswapV2Router), 0);
    }

    receive() external payable {}
}
