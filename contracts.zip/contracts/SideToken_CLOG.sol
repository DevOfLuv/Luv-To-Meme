// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {SideToken_ERC20} from "./SideToken_ERC20.sol";
import {ITokenFactoryBase} from "./interfaces/ITokenFactoryBase.sol";
import {IUniswapV2Router02} from "./interfaces/IUniswapV2Router02.sol";


contract SideToken_CLOG is SideToken_ERC20 {
    uint16 public constant FEE_DENOMINATOR = 1000;

    address public startPair;
    address public uniswapRouterAdr;

    address public feeAccount;

    uint public txnCount;

    ClogParams public contractStruct;

    event FeeAccountChanged(address oldAccount, address newAccount);

    struct ClogParams {
        uint16 startFeeNominator;
        uint16 endFeeNominator;
        uint maxWalletAmountStart;
        uint maxWalletAmountEnd;
        uint txnCountLimit;
    }

    constructor(
        string memory name_,
        string memory symbol_,
        uint8 decimals_,
        uint totalSupply_,
        address mediaAccount_,
        address feeAccount_,
        uint salt_,
        ClogParams memory contractStruct_,
        address uniswapRouterAdr_,
        Metadata memory metadata_,
        address mainTokenAdr_
    )
        SideToken_ERC20(
            name_,
            symbol_,
            decimals_,
            totalSupply_,
            mediaAccount_,
            salt_,
            metadata_,
            mainTokenAdr_
        )
    {
        require(
            contractStruct_.startFeeNominator <= 900,
            "SideToken_CLOG: startFeeNominator_ needs to be less equal or less 900 (90.0%)."
        );
        require(
            contractStruct_.endFeeNominator <= 250,
            "SideToken_CLOG: endFeeNominator_ needs to be less equal or less 250 (25.0%)."
        );
        require(
            contractStruct_.maxWalletAmountStart <= totalSupply_,
            "SideToken_CLOG: maxWalletAmountStart_ needs to be equal or less totalSupply_ (100%)."
        );
        require(
            contractStruct_.maxWalletAmountStart >= totalSupply_ / 10000,
            "SideToken_CLOG: maxWalletAmountStart_ needs to be equal or bigger totalSupply_ / 10000 (0.01%)."
        );
        require(
            contractStruct_.maxWalletAmountEnd >= totalSupply_ / 50,
            "SideToken_CLOG: maxWalletAmountEnd_ needs to be equal or more totalSupply_ / 50 (2%)."
        );
        require(
            contractStruct_.maxWalletAmountEnd <= totalSupply_,
            "SideToken_CLOG: maxWalletAmountEnd_ needs to be equal or less totalSupply_ (100%)."
        );
        require(
            contractStruct_.txnCountLimit <= 100,
            "SideToken_CLOG: txnCountLimit_ needs to be equal or less 100."
        );
        require(
            feeAccount_ != address(this),
            "SideToken_CLOG: feeAccount_ needs to be different than the contract address."
        );
        
        feeAccount = feeAccount_;
        contractStruct = contractStruct_;
        uniswapRouterAdr = uniswapRouterAdr_;
        // _changeUnlimitedAccount(address(this), true);
    }

    /**
     * @dev Sets the initial pair address for the token.
     * This function can only be called once, as it requires the startPair to be unset (address(0)).
     *
     * @param startPair_ The address of the initial pair to be set.
     *
     * NOTE: This function is called from the factory in the same transaction as the contract creation,
     * so no safety checks are needed because no one can call it before the factory or after.
     */
    function setStartPair(address startPair_) external {
        require(
            startPair == address(0),
            "SideToken_CLOG: startPair already set."
        );
        startPair = startPair_;
    }

    /**
     * @dev Returns the current fee nominator based on the transaction count.
     *
     * @return uint16 The current fee nominator.
     */
    function getCurrentNominator() external view returns (uint16) {
        if (txnCount < contractStruct.txnCountLimit) {
            return contractStruct.startFeeNominator;
        } else {
            return contractStruct.endFeeNominator;
        }
    }

    /**
     * @dev Handles the transfer of tokens from one address to another, applying
     * fees and updating balances accordingly. This function is intended for internal
     * use and overrides the base implementation of {ERC20.sol}. Also `_checkAndSwapClog` is called
     * at the beinning.
     *
     * @param from_ The address from which tokens are being transferred.
     * @param to_ The address to which tokens are being transferred.
     * @param amount_ The amount of tokens to transfer.
     *
     * NOTE: The function includes logic to determine the applicable transaction fees
     * based on the transaction count and will fail if the maxWalletAmountStart or maxWalletAmountEnd
     * is exceeded. The startPair is excluded from max wallet restrictions, while the fee account and
     * the factory are excluded from both max wallet restrictions and fees.
     * Also transactions from the first liquidity pool triggering a swap if 'contractStruct.txnCountLimit' is not reached.
     * Otherwise the 'feeAccount' gets the fee.
     *
     * WARNING: Ensure that the transfer complies with the max wallet amount limits
     * set in the contract, otherwise, it will revert. The fees are applied
     * differently before and after reaching a transaction count limit.
     */
    function _transfer(
        address from_,
        address to_,
        uint amount_
    ) internal override {
        uint fee = 0;
        bool isExcluded = to_ == startPair;

        if (
            from_ == feeAccount ||
            to_ == feeAccount ||
            from_ == tokenFactory ||
            to_ == tokenFactory ||
            from_ == address(this) ||
            iMainToken.feeExcluded(from_) ||
            iMainToken.feeExcluded(to_)
        ) {
            super._transferWithNoLimit(from_, to_, amount_);
        } else {
            if (txnCount < contractStruct.txnCountLimit) {
                fee =
                    (amount_ * contractStruct.startFeeNominator) /
                    FEE_DENOMINATOR;
                amount_ = amount_ - fee;
                require(
                    amount_ + balanceOf(to_) <=
                        contractStruct.maxWalletAmountStart ||
                        isExcluded,
                    "SideToken_CLOG: amount plus balance of the receiver needs to be equal or less than maxWalletAmountStart"
                );
                if (fee > 0) {
                    super._transferWithNoLimit(from_, address(this), fee);
                }

                txnCount++;
            } else {
                fee =
                    (amount_ * contractStruct.endFeeNominator) /
                    FEE_DENOMINATOR;
                amount_ = amount_ - fee;
                require(
                    amount_ + balanceOf(to_) <=
                        contractStruct.maxWalletAmountEnd ||
                        isExcluded,
                    "SideToken_CLOG: amount plus balance of the receiver needs to be equal or less than maxWalletAmountEnd"
                );
                if (fee > 0) {
                    super._transferWithNoLimit(from_, feeAccount, fee);
                }
            }
            super._transfer(from_, to_, amount_);
        }
        _checkAndSwapClog(from_, amount_);
    }

    /**
     * @dev Checks the current token balance ("clog") held by the contract and determines
     * whether a portion of it should be swapped based on certain conditions. This helps
     * manage liquidity by deciding how much to sell.
     *
     * @param from_ The address initiating the transfer.
     * @param amount_ The amount of tokens involved in the transaction.
     *
     * NOTE: The function calculates `toSellAmount` as 10% of the transaction amount initially.
     * This amount is adjusted based on the contract's balance and conditions specified in
     * `contractStruct`.
     *
     * WARNING: The swap operation will occur if the conditions are met, potentially affecting
     * liquidity dynamics. Ensure that the `contractStruct` parameters are set correctly to
     * avoid unintended swaps.
     */
    function _checkAndSwapClog(address from_, uint amount_) internal {
        uint toSellAmount = 0;
        uint clog = balanceOf(address(this));

        if (clog > 0) {
            uint tempAmount = amount_ / 10;
            if (from_ == startPair) {
                toSellAmount = tempAmount <= clog ? tempAmount : clog;
            }
            if (toSellAmount > 0) {
                _swapClog(toSellAmount);
            }
        }
    }

    /**
     * @dev Swaps a specified amount of the contract's tokens for another token using the Uniswap V2 Router.
     * This is a private function that helps in managing liquidity by converting the token clog into another token.
     *
     * @param amount_ The amount of tokens to swap from the contract's balance.
     *
     * NOTE: The swap is conducted through a path from the contract's token to the main token specified by
     * the token factory. The function approves the Uniswap router to spend the specified token amount before
     * performing the swap.
     *
     * WARNING: Ensure that the Uniswap router address and the main token address are correctly configured
     * in the contract to prevent failed swaps or unexpected behavior.
     */
    function _swapClog(uint256 amount_) private {
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = ITokenFactoryBase(tokenFactory).mainTokenAdr();
        _approve(address(this), address(uniswapRouterAdr), amount_);
        IUniswapV2Router02(uniswapRouterAdr)
            .swapExactTokensForTokensSupportingFeeOnTransferTokens(
                amount_,
                0,
                path,
                feeAccount,
                block.timestamp
            );
    }

    /**
     * @dev Removes the transaction limits by setting the transaction count to the
     * transaction count limit specified in the contract. This effectively disables
     * the transaction limit feature.
     *
     * NOTE: Only the `feeAccount` is authorized to call this function to ensure control
     * over when limits are removed.
     *
     * WARNING: Once the limits are removed, they cannot be reinstated using this function,
     * as it sets the `txnCount` to `contractStruct.txnCountLimit`, effectively disabling
     * the limit checks.
     */
    function removeLimits() external {
        require(
            msg.sender == feeAccount,
            "SideToken_CLOG: Only the feeAccount can call this function."
        );
        txnCount = contractStruct.txnCountLimit;
    }

    /**
     * @dev Allows the `feeAccount` to manually swap a specified amount of the contract's tokens
     * using the `_swapClog` function. This function gives the fee account control over
     * managing the token clog manually.
     *
     * @param toSellAmount The amount of tokens to be swapped.
     *
     * NOTE: This function provides the fee account with the flexibility to initiate a swap
     * outside of the automated processes defined in the contract.
     *
     * WARNING: This function will fataly fail if there is no clog amount.
     * Only the `feeAccount` is allowed to execute this function. Ensure that the
     * `toSellAmount` is correctly calculated to prevent unwanted token balance changes.
     */
    function manualSwap(uint toSellAmount) external {
        require(
            _msgSender() == feeAccount,
            "SideToken_CLOG: Only the feeAccount can call this function."
        );
        _swapClog(toSellAmount);
    }

    /**
     * @dev Allows the `feeAccount` to change the fee account.
     *
     * @param newFeeAccount_ The new fee account address.
     */
    function changeFeeAccount(address newFeeAccount_) external {
        require(
            msg.sender == feeAccount,
            "SideToken_CLOG: Only the feeAccount() can change the feeAccount()."
        );
        require(
            newFeeAccount_ != address(this),
            "SideToken_CLOG: newFeeAccount_ needs to be different than the contract address."
        );
        address oldAccount = feeAccount;
        feeAccount = newFeeAccount_;
        emit FeeAccountChanged(oldAccount, newFeeAccount_);
    }
}
