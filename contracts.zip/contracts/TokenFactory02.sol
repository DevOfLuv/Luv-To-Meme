// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import {SideToken_FEE} from "./SideToken_FEE.sol";
import {IUniswapV2Factory} from "./interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "./interfaces/IUniswapV2Router02.sol";
import {IMainToken} from "./interfaces/IMainToken.sol";
import {ISideToken_CLOG} from "./interfaces/ISideToken_CLOG.sol";
import {TokenFactoryBase} from "./TokenFactoryBase.sol";


contract TokenFactory02 is TokenFactoryBase {

    constructor(address initialOwner_) TokenFactoryBase(initialOwner_){}
    
    /**
     * @dev Creates a new FEE token with the specified parameters and adds liquidity for it. 
     * This function facilitates the creation and initial setup of a new fee-charging token, 
     * including minting, liquidity provision, and tracking the new token.
     * 
     * @param name_ The name of the new FEE token.
     * @param symbol_ The symbol of the new FEE token.
     * @param decimals_ The number of decimals the token uses.
     * @param totalSupply_ The initial total supply of the new token.
     * @param mediaAccount_ The address associated with media accounts or promotion.
     * @param mainTokenAmount_ The amount of main tokens to use for liquidity.
     * @param feeAccount_ The address where fees collected from token transactions are sent.
     * @param feeNominator_ The fee percentage (as a nominator) applied to transactions.
     * @param salt_ A unique salt value used for deploying the new token.
     * @param firstBuyAmount_ The amount for the first buy to be triggered.
     * @param metadata_ The metadata associated with the new token, containing additional configuration.
     * 
     * NOTE: This function creates a new `SideToken_FEE` instance and mints main tokens for it,
     * setting up initial liquidity on Uniswap. It also updates internal tracking for created tokens.
     */
    function createFEEToken(
        string memory name_, string memory symbol_, uint8 decimals_, uint totalSupply_, address mediaAccount_, uint mainTokenAmount_, address feeAccount_, uint16 feeNominator_, uint salt_, uint firstBuyAmount_,
        SideToken_FEE.Metadata memory metadata_
    ) external {
        SideToken_FEE newToken = new SideToken_FEE(name_, symbol_, decimals_, totalSupply_, mediaAccount_, feeAccount_, feeNominator_, salt_, metadata_, mainTokenAdr);

        IMainToken(mainTokenAdr).factoryMint(mainTokenAmount_, address(newToken), firstBuyAmount_, msg.sender);

        _setValues(address(newToken), TokenType.FEE);
    }

}