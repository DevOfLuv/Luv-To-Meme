// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";


contract StakedToken is ERC20 {

    //Staking contract to deposit and withdraw maintoken.
    address public immutable STAKING_CONTRACT_ADDRESS;

    constructor(string memory name_, string memory symbol_) ERC20(name_, symbol_) {
        STAKING_CONTRACT_ADDRESS = msg.sender;
    }

    /**
     * @dev Mints a specified amount of tokens to a given address. This function is restricted
     * to being called only by the staking contract address, ensuring that minting is controlled.
     * 
     * @param to_ The address to which the minted tokens will be sent.
     * @param amount_ The amount of tokens to mint.
     * 
     * NOTE: This function is intended to support staking operations by allowing the staking contract
     * to mint tokens as needed.
     * 
     * WARNING: Only the `STAKING_CONTRACT_ADDRESS` is permitted to call this function. Unauthorized calls
     * will revert with an error message.
     */
    function mint(address to_, uint amount_) external {
        require(msg.sender == STAKING_CONTRACT_ADDRESS, "StakingToken: Only the STAKING_CONTRACT_ADDRESS can call this function.");
        _mint(to_, amount_);
    }

    /**
     * @dev Burns a specified amount of tokens from a given address. This function is restricted
     * to being called only by the staking contract address, ensuring that burning is controlled.
     * 
     * @param from_ The address from which the tokens will be burned.
     * @param amount_ The amount of tokens to burn.
     * 
     * NOTE: This function is designed to facilitate staking operations by allowing the staking contract
     * to burn tokens as necessary.
     * 
     * WARNING: Only the `STAKING_CONTRACT_ADDRESS` is permitted to call this function. Unauthorized calls
     * will revert with an error message.
     */
    function burn(address from_, uint amount_) external {
        require(msg.sender == STAKING_CONTRACT_ADDRESS, "StakingToken: Only the STAKING_CONTRACT_ADDRESS can call this function.");
        _burn(from_, amount_);
    }

}