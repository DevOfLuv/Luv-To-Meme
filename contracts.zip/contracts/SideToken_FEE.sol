// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {SideToken_ERC20} from "./SideToken_ERC20.sol";

contract SideToken_FEE is SideToken_ERC20 {

    address public feeAccount;

    uint16 public constant FEE_DENOMINATOR = 1000;
    uint16 public feeNominator;

    event FeeAccountChanged(address oldAccount, address newAccount);

    constructor(
        string memory name_,
        string memory symbol_,
        uint8 decimals_,
        uint totalSupply_,
        address mediaAccount_,
        address feeAccount_,
        uint16 feeNominator_,
        uint salt_,
        Metadata memory metadata_,
        address mainTokenAdr_
    )
        SideToken_ERC20(
            name_,
            symbol_,
            decimals_,
            totalSupply_,
            mediaAccount_,
            salt_,
            metadata_,
            mainTokenAdr_
        )
    {
        require(feeNominator_ <= 250, 
            "SideToken_FEE: Max fee is 250 (25.0%)."
        );
        require(
            feeAccount_ != address(this),
            "SideToken_CLOG: feeAccount_ needs to be different than the contract address."
        );
        feeNominator = feeNominator_;
        feeAccount = feeAccount_;
    }

    /**
     * @dev Transfers tokens from one address to another, applying a transaction fee unless
     * the transfer involves specific exempt accounts. This function overrides the internal
     * transfer method to include fee deduction logic.
     *
     * @param from The address from which the tokens are being transferred.
     * @param to The address to which the tokens are being transferred.
     * @param value The amount of tokens to transfer.
     *
     * NOTE: Transfers involving the `feeAccount` or `tokenFactory` are exempt from fees.
     *
     * WARNING: Transfers to or from the zero address will revert, ensuring that invalid
     * transfers are not executed.
     */
    function _transfer(
        address from,
        address to,
        uint256 value
    ) internal override {
        if (from == address(0)) {
            revert ERC20InvalidSender(address(0));
        }
        if (to == address(0)) {
            revert ERC20InvalidReceiver(address(0));
        }

        if (
            from == feeAccount ||
            to == feeAccount ||
            from == tokenFactory ||
            to == tokenFactory ||
            iMainToken.feeExcluded(from) ||
            iMainToken.feeExcluded(to)
        ) {
            super._transferWithNoLimit(from, to, value);
        } else {
            uint fee = (value * feeNominator) / FEE_DENOMINATOR;
            super._transferWithNoLimit(from, feeAccount, fee);
            super._transfer(from, to, value - fee);
        }
    }

    /**
     * @dev Changes the fee account to a new address.
     *
     * @param newFeeAccount_ The new address to set as the fee account.
     */
    function changeFeeAccount(address newFeeAccount_) external {
        require(
            msg.sender == feeAccount,
            "SideToken_FEE: Only the current feeAccount() can change the feeAccount()."
        );
        require(
            newFeeAccount_ != address(this),
            "SideToken_CLOG: newFeeAccount_ needs to be different than the contract address."
        );
        address oldAccount = feeAccount;
        feeAccount = newFeeAccount_;
        emit FeeAccountChanged(oldAccount, newFeeAccount_);
    }
}
