// SPDX-License-Identifier: BUSL-1.1
// OpenZeppelin Contracts (last updated v5.0.0) (token/ERC20/ERC20.sol)

pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

import {MEMEMetadata} from "./utils/MEMEMetadata.sol";
import {ERC20_for_Mone} from "./utils/ERC20_for_Mone.sol";
import {BotProtector} from "./utils/BotProtector.sol";
import {IUniswapV2Factory} from "./interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "./interfaces/IUniswapV2Router02.sol";
import {ITokenFactoryBase} from "./interfaces/ITokenFactoryBase.sol";
import {ISwapper} from "./interfaces/ISwapper.sol";
import {OwnableHandshake} from "./utils/OwnableHandshake.sol";
import {Swapper} from "./utils/Swapper.sol";


contract Mone is ERC20_for_Mone, BotProtector, OwnableHandshake, MEMEMetadata {
    using SafeERC20 for IERC20;

    //Dead Address for liquidity token check
    address public constant DEAD_ADDRESS = 0x000000000000000000000000000000000000dEaD;

    address public collateral;

    //Address of the Swapper contract
    address public swapper;

    //Fee constants to caluclate fees 'amount * feeNominator / FEE_DENOMINATOR'
    uint32 public constant FEE_DENOMINATOR = 100000;
    //Max setable fee (1%)
    uint16 public constant MAX_FEE_NOMINATOR = 1000;
    uint16 public feeNominator = 400;

    //Account receiving transaction fees.
    address public feeAccount;

    //Address of contract creating the start liquidity
    address liquidityAdder;
    //Bool to check if start liquidity are deployed
    bool startLiquiditySet;


    // ETH
    // address public constant UNISWAP_ROUTER = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D;
    // address public constant UNISWAP_FACTORY = 0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f;
    // address public constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;


    // Testnet
    // address public constant UNISWAP_ROUTER = 0xD99D1c33F9fC3444f8101754aBC46c52416550D1;
    // address public constant UNISWAP_FACTORY = 0x6725F303b657a9451d8BA641348b6761A6CC7a17;
    // address public constant WETH = 0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd;

    // BASE
    address public constant UNISWAP_ROUTER = 0x4752ba5DBc23f44D87826276BF6Fd6b1C372aD24;
    address public constant UNISWAP_FACTORY = 0x8909Dc15e40173Ff4699343b6eB8132c65e18eC6;
    address public constant WETH = 0x4200000000000000000000000000000000000006;


    //Token factories to create new tokens, are allowed to mint.
    mapping (address => bool) public isTokenFactory;
    mapping (address => bool) public unlimitedSetters;



    event TokenFactorySet(address tokenFactory, bool state);
    event NewPairCreated(address pairedToken);
    event ChangedFee(uint newFeeNominator);
    event ChangedFeeAccount(address newFeeAccount);
    event ChangedFeeExcludedAccount(address account, bool state);
    event ResetVirtualSupply();
    event SwapperChanged(address oldSwapper, address newSwapper);

    constructor(address initialOwner_, string memory name_, string memory symbol_, address feeAccount_, address collateralTokenAdr_, uint mintAmount_,uint salt_, Metadata memory metadata_) 
        ERC20_for_Mone(name_, symbol_)
        BotProtector(address(this)) 
        MEMEMetadata(msg.sender, metadata_)
        OwnableHandshake(initialOwner_) {

            IERC20(collateralTokenAdr_).safeTransferFrom(msg.sender, address(this), mintAmount_);
            _mintAvailableSupply(msg.sender, mintAmount_);

            collateral = collateralTokenAdr_;

            feeAccount = feeAccount_;
            _changeUnlimitedAccount(address(this), true);
            _changeUnlimitedAccount(msg.sender, true);

            emit ChangedFeeExcludedAccount(feeAccount_, true);            
            emit ChangedFeeExcludedAccount(msg.sender, true);            
        }

    function setUnlimitedSetter(address setter, bool state) external onlyOwner {
        unlimitedSetters[setter] = state;
    }
        
    /**
     * @dev Allows the owner to change the swapper address.
     *
     * @param newSwapper The new swapper address.
     */
    function changeSwapper(address newSwapper) external onlyOwner {
        emit SwapperChanged(swapper, newSwapper);
        swapper = newSwapper;
    }

    /**
     * @dev Allows the owner to designate an account as unlimited or not. Unlimited accounts are exempt 
     *      from transfer limits enforced by the `BotProtector` mechanism.
     *
     * @param account_ The address of the account to update.
     * @param unlimited_ A boolean indicating whether to set the account as unlimited (`true`) or not (`false`).
     */
    function changeUnlimitedAccount(address account_, bool unlimited_) external {
        require(unlimitedSetters[msg.sender] || msg.sender == owner(), "Mone: Only the unlimitedSetter or owner can call this function.");
        _changeUnlimitedAccount(account_, unlimited_);
    }

    /**
     * @dev Allows the owner to change the fee exclusion state and the unlimited state of multiple accounts.
     *
     * @param accounts_ An array of addresses of the accounts to update.
     * @param state_ A boolean indicating whether to set the accounts as fee excluded (`true`) or not (`false`).
     */
    function changeUnlimitedAccounts(address[] calldata accounts_, bool state_) external onlyOwner {
        for (uint i = 0; i < accounts_.length; i++) {
            _changeUnlimitedAccount(accounts_[i], state_);
        }
    }

    /**
     * @dev Accepts the ownership transfer.
     * 
     * NOTE: Remove the fee exclusion of the old owner and set the new owner to fee excluded.
     *       The 'newOwner' has to call 'acceptOwnership'.
     *       If 'submitTransferOwnership' is called before the old 'newOwner' accepted the ownership
     *       the new 'newOwner' can accept the old one not anymore.
     */
    function acceptOwnership() public override {
        require(msg.sender == submittedOwner(), "Mone: Only the 'submittedOwner' can accept the ownership.");
        _transferOwnership(submittedOwner());
        emit OwnershipTransferAccepted();
    }

    /**
     * @dev Allows the owner to change the ownership after deployment.
     * 
     * NOTE: Only the owner can call this function.
     *       The 'newOwner' has to call 'acceptOwnership' after the deployment.
     */
    function changeOwnershipAfterDeployment(address newOwner) external override onlyOwner {
        require(!firstOverTake);
        _transferOwnership(newOwner);
        firstOverTake = true;
    }

     /**
     * @dev Allows the owner to change the transaction fee percentage.
     *
     * The fee is set as a fraction of the total transfer amount, calculated using `feeNominator / FEE_DENOMINATOR`.
     *
     * Requirements:
     *
     * - The caller must be the owner of the contract.
     * - The new `feeNominator` must be less than or equal to `MAX_FEE_NOMINATOR` (1%).
     *
     * @param feeNominator_ The new fee nominator value, representing the percentage of the transfer amount to be taken as a fee.
     */
    function changeFee(uint16 feeNominator_) external onlyOwner {
        require(feeNominator_ <= MAX_FEE_NOMINATOR, "Mone: max 'feeNominator' is 1000 or 1%.");
        feeNominator = feeNominator_;
        emit ChangedFee(feeNominator);
    }


    /**
     * @dev Allows the owner to change the account where transaction fees are collected.
     *
     * The `feeAccount` is the address that will receive the transaction fees collected by the contract.
     *
     * @param feeAccount_ The new fee account address.
     */
    function changeFeeAccount(address feeAccount_) external onlyOwner {
        feeAccount = feeAccount_;
        emit ChangedFeeAccount(feeAccount);
    }

     /**
     * @dev Allows the owner to change the state of a token factory, enabling or disabling it.
     *
     * The function sets the `isTokenFactory` status and changes the unlimited account status of the provided token factory address.
     * The fee exclusion status of the token factory address is also updated accordingly.
     *
     *
     * @param tokenFactoryAdr_ The address of the token factory to update.
     * @param state_ A boolean indicating whether the token factory should be enabled (`true`) or disabled (`false`).
     */
    function changeTokenFactoryState(address tokenFactoryAdr_, bool state_) external onlyOwner {
        isTokenFactory[tokenFactoryAdr_] = state_;
        _changeUnlimitedAccount(tokenFactoryAdr_, state_);

        emit TokenFactorySet(tokenFactoryAdr_, state_);
    }


    function depositRatio(uint amount) public view returns (uint) {
        uint ratio = amount * availableSupply() * 1e6;
        return ratio / (IERC20(collateral).balanceOf(address(this)) * 1e6);
    }

    function deposit(uint amount) external protectAgainsBots(address(this), msg.sender) {
        IERC20(collateral).safeTransferFrom(msg.sender, address(this), amount);

        uint toMint = depositRatio(amount);
        uint fee = toMint * feeNominator / FEE_DENOMINATOR;
        uint toOwner = toMint - fee;
        
        _mintAvailableSupply(msg.sender, toOwner);
        _mintAvailableSupply(feeAccount, fee);
    }

    function withdrawRatio(uint amount) public view returns (uint) {
        uint ratio = amount * IERC20(collateral).balanceOf(address(this)) * 1e6;
        return ratio / (availableSupply() * 1e6);
    }

    function withdraw(uint amount) external protectAgainsBots(msg.sender, address(this)) {
        uint fee = amount * feeNominator / FEE_DENOMINATOR;
        uint afterFee = amount - fee;    
        uint toOwner = withdrawRatio(afterFee);

        IERC20(address(this)).safeTransferFrom(msg.sender, feeAccount, fee);
        IERC20(collateral).safeTransfer(msg.sender, toOwner);

        _burnAvailableSupply(msg.sender, amount);
    }

        /**
     * @dev Moves a `value` amount of tokens from `from` to `to`.
     *
     * This internal function is equivalent to {transfer}, and can be used to
     * e.g. implement automatic token fees, slashing mechanisms, etc.
     *
     * Emits a {Transfer} event.
     *
     * NOTE: Changed this function to use the 'proctectAgainsBots' modifier. And add a transaction fee.
     */
    function _transfer(address from, address to, uint value) internal override protectAgainsBots(from, to) {
        super._transfer(from, to, value);
    }


    /**
     * @dev Allows a verified token factory to mint tokens, add liquidity to the Uniswap pool,
     * and optionally trigger a first buy. This function is used to facilitate the initial
     * distribution and liquidity setup of a new token.
     * 
     * @param mainTokenAmount_ The amount of main tokens to mint.
     * @param forToken_ The address of the token for which liquidity is being added.
     * @param firstBuyAmount_ The amount of the first buy to trigger, if any.
     * @param to_ The address to receive the tokens from the first buy.
     * 
     * NOTE: This function conducts a safety check to ensure that the pair token supply is fully burned,
     * and that the new token supply is entirely placed in the liquidity pool.
     * It prevents malicious factory from adding liquidity to some degree. Make sure that the added factories have a compatible uniswapV2Factory 
     * set as 'uniswapFactoryAdr' in the 'TokenFactoryBase' contract.
     * 
     * WARNING: Only addresses listed in `isTokenFactory` can call this function. The minting
     * amount must not exceed `MAX_MINT_AMOUNT` to prevent over-minting.
     */
    function factoryMint(uint mainTokenAmount_, address forToken_, uint firstBuyAmount_, address to_) external {
        address sender = msg.sender;    
        require(isTokenFactory[sender], "Mone: Only the tokenFactory can call this function.");
        require(mainTokenAmount_ <= MAX_MINT_AMOUNT, "Mone: you can only mint MAX_MINT_AMOUNT tokens.");

        _mintVirtualSupply(sender, mainTokenAmount_);

        ITokenFactoryBase(sender).addLiquidity(forToken_, mainTokenAmount_);

        //Safety check to prevent malicious factory adding   
        address pairFactory = ITokenFactoryBase(sender).uniswapFactoryAdr();
        address newPair = IUniswapV2Factory(pairFactory).getPair(address(this), forToken_);
        uint pairSupply = IERC20(newPair).totalSupply();
        uint newTokenSupply = IERC20(forToken_).totalSupply();
        uint pairBalance = IERC20(forToken_).balanceOf(newPair);
        uint zeroBalance = IERC20(newPair).balanceOf(address(0));

        _changeUnlimitedAccount(newPair, true);

        require(zeroBalance == pairSupply, "Mone: The pair token supply is not completly burned.");
        require(pairBalance == newTokenSupply, "Mone: The new token supply is not completly in the liquidity pool.");

        if (firstBuyAmount_ > 0) {
            ITokenFactoryBase(msg.sender).triggerFirstBuy(forToken_, firstBuyAmount_, to_);
        }
    }
}
