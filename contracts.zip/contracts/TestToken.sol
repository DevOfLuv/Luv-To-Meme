// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract TestToken is ERC20{

    constructor(string memory name_, string memory symbol_) ERC20(name_, symbol_) {
        _mint(msg.sender, 1e30);
    }

    function testMint() external {
        _mint(msg.sender, 1e30);
    }

    function testMintAmount(uint amount) external {
        _mint(msg.sender, amount);
    }

    function decimals() public view override returns(uint8) {
        return 6;
    }

}