// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {MEMEMetadata} from "./utils/MEMEMetadata.sol";
import {ERC20} from "./utils/ERC20.sol";
import {IMainToken} from "./interfaces/IMainToken.sol";
import {BotProtector} from "./utils/BotProtector.sol";



contract SideToken_ERC20 is ERC20, MEMEMetadata, BotProtector {
    IMainToken public iMainToken;

    mapping (address => uint) public lastTransactionOfAccount;

    address public tokenFactory;
    

    uint8 private _decimals;
    uint private salt;
    constructor(string memory name_, string memory symbol_, uint8 decimals_, uint totalSupply_, address mediaAccount_, uint salt_, Metadata memory metadata_, address mainTokenAdr_) 
        ERC20(name_, symbol_) 
        BotProtector(address(mainTokenAdr_))
        MEMEMetadata(mediaAccount_, metadata_) 
        {
            require(
                totalSupply_ >= 1000000,
            "SideToken_ERC20: totalSupply_ needs to be equal or more 1,000,000."
        );

        _mint(msg.sender, totalSupply_);
        _decimals = decimals_;
        salt = salt_;
        iMainToken = IMainToken(mainTokenAdr_);
        tokenFactory = msg.sender;
        _changeUnlimitedAccount(msg.sender, true);
    }

    /**
     * @dev Returns the set decimals.
     *
     */
    function decimals() public view override returns(uint8) {
        return _decimals;
    }

    /**
     * @dev Overrides the ERC20 `_transfer` function to include anti-bot transaction limitations.
     *
     * This function enforces a restriction that prevents an account from making more than one
     * transaction within the same block, thereby mitigating bot-driven trading activities.
     * Accounts marked as unlimited by the main token contract (`IMainToken`) are exempt from
     * this restriction and can perform multiple transactions per block.
     *
     * @param from The address send from.
     * @param to The address send to.
     * @param value The amount of tokens to be transferred.
     *
     * @notice
     * - If either the sender or the recipient has already performed a transaction in the current block
     *   and is not marked as unlimited, the transaction will revert.
     * - The `lastTransactionOfAccount` is updated to track the block number of the latest transaction
     *   for each account, enabling the enforcement of the one-transaction-per-block rule.
     *
     * @custom:security
     * - Relies on the correctness and security of the external `IMainToken.unlimitedTransactionAccount` function.
     * - Ensure that the `IMainToken` contract is trusted and properly audited to prevent bypassing the anti-bot mechanism.
     */
    function _transfer(address from, address to, uint value) internal virtual override protectAgainsBots(from, to) {
        super._transfer(from, to, value);
    }

    /**
     * @dev Internal function to transfer tokens without any transaction limitations.
     *
     */
    function _transferWithNoLimit(address from, address to, uint value) internal {
        super._transfer(from, to, value);
    }
}