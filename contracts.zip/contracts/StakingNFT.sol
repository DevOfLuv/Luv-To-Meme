// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {OwnableHandshake} from "./utils/OwnableHandshake.sol";

import {StakedToken} from "./StakedToken.sol";

contract StakingNFT is ERC721, OwnableHandshake {

    //Address of the maintoken
    address public mainTokenAdr;

    //locked time of 90 days
    uint public constant LOCK_TIME = 60*60*24*90;

    struct NFTInfo {
        uint alreadyClaimed;
        uint claimable;
        uint claimableAt;
    }

    mapping (uint => NFTInfo) public nftInfo;

    //represents the tokenId
    uint public totalSupply;
    //Displays the amount which is claimable after lock time
    uint public totalClaimableAfterLock;

    //No real need
    string public baseURI;

    //token representation of stakes are 1:1 staked token
    StakedToken immutable public iStakedToken;

    event BaseURIChanged(string newBaseURI);
    event WithdrawNFTCreated(address user, uint nftId, uint claimableAmount, uint claimableAtTimestamp);
    event Withdrawl(address user, uint nftId, uint amount);
    event Stake(address user, uint amount);

    constructor(address initialOwner_, string memory name_, string memory symbol_, address mainTokenAdr_) ERC721(name_, symbol_) OwnableHandshake(initialOwner_) {
        mainTokenAdr = mainTokenAdr_;
        iStakedToken = new StakedToken("Free LUV", "freeLUV");
    }

    /**
     * @dev Returns the address of the token which represent the stakes 1:1
     * 
     */
    function stakedTokenAddress() external view returns(address) {
        return address(iStakedToken);
    }

    /**
     * @dev Allows the contract owner to change the base URI used for computing token URIs.
     * This function emits a `BaseURIChanged` event upon a successful change.
     * 
     * @param baseURI_ The new base URI to be set.
     * 
     * NOTE: This function can only be called by the contract owner, ensuring control over URI changes.
     */
    function changeBaseURI(string memory baseURI_) external onlyOwner {
        baseURI = baseURI_;
        emit BaseURIChanged(baseURI_);
    }

    /**
     * @dev Allows a user to stake a specified amount of main tokens. The staked tokens are transferred
     * to the contract, and an equivalent amount of staked tokens is minted to the user.
     * 
     * @param amount_ The amount of main tokens to stake.
     * 
     * NOTE: This function transfers the specified amount of main tokens from the user to the contract
     * and mints staked tokens for the user, facilitating the staking process.
     */
    function stake(uint amount_) external {
        IERC20(mainTokenAdr).transferFrom(msg.sender, address(this), amount_);
        iStakedToken.mint(msg.sender, amount_);
        emit Stake(msg.sender, amount_);
    }

    /**
     * @dev Allows a user to unstake a specified amount of staked tokens. The staked tokens are burned,
     * and a new NFT is minted, representing the user's claimable amount.
     * 
     * @param amount_ The amount of staked tokens to unstake.
     * 
     * NOTE: This function also sets a lock time for the claimable tokens, requiring them to remain
     * locked for a specified period before they can be withdrawn.
     * The `totalSupply` is incremented to track the minting of new NFTs representing claimable amounts.
     */
    function unstake(uint amount_) external { 
        uint lockTime = block.timestamp + LOCK_TIME;
        iStakedToken.burn(msg.sender, amount_);
        _mint(msg.sender, totalSupply);
        nftInfo[totalSupply].claimable = amount_;
        nftInfo[totalSupply].claimableAt = lockTime;
        totalClaimableAfterLock += amount_;
        totalSupply++;
        emit WithdrawNFTCreated(msg.sender, totalSupply-1, amount_, lockTime);
    }

    /**
     * @dev Calculates the claimable amount for an NFT based on the current timestamp and the lock time.
     *
     * @param tokenId_ The ID of the NFT to calculate the claimable amount for.
     * @return claimableAmount The calculated claimable amount.
     * 
     * NOTE: This function calculates the claimable amount based on the current timestamp and the lock time,
     * ensuring that the correct amount is returned for the given NFT.
     */
    function claimableNow(uint tokenId_) public view returns(uint claimableAmount) {
        uint bts = block.timestamp;
        if (bts >= nftInfo[tokenId_].claimableAt) {
            claimableAmount = nftInfo[tokenId_].claimable - nftInfo[tokenId_].alreadyClaimed; 
        } else {
            uint start = nftInfo[tokenId_].claimableAt - LOCK_TIME;
            uint dif = bts - start;
            uint claimablePerSecond = nftInfo[tokenId_].claimable / LOCK_TIME;
            claimableAmount = dif * claimablePerSecond - nftInfo[tokenId_].alreadyClaimed;
        }
    }

    /**
     * @dev Allows the owner of an NFT to claim their claimable tokens.
     *
     * @param tokenId_ The ID of the NFT representing the claimable tokens.
     * 
     * NOTE: This function ensures that only the NFT owner can claim the tokens and that the tokens are not
     * claimed before the lock period ends.
     */
    function claim(uint tokenId_) external {
        require(ownerOf(tokenId_) == msg.sender, "StakingNFT: Only the owner of the NFT can withdraw the tokens.");

        uint amount = claimableNow(tokenId_);
        nftInfo[tokenId_].alreadyClaimed += amount;

        IERC20(mainTokenAdr).transfer(msg.sender, amount);
        emit Withdrawl(msg.sender, tokenId_, amount);
    }

    /**
     * @dev Base URI for computing `tokenURI`. If set, the resulting URI for each token will be the
     * concatenation of the `baseURI` and the `tokenId`. Empty by default, can be overridden in child contracts.
     * 
     * @return The base URI used for computing the `tokenURI`.
     * 
     * NOTE: This function is internal and can be overridden by derived contracts to provide custom URI logic.
     */
    function _baseURI() internal view override returns (string memory) {
        return baseURI;
    }

}