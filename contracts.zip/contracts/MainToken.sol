// SPDX-License-Identifier: BUSL-1.1
// OpenZeppelin Contracts (last updated v5.0.0) (token/ERC20/ERC20.sol)

// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMNX0kkxxxxxkO0XWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWXKOkxxxxxkk0XNMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMWNKxlc:::;:::::;;;:::clxOXWMMMMMMMMMMMMMMMMMMMMWXOxlc:c:;;:::::;;;::clxKWMMMMMMMMMMMMMM
// MMMMMMMMMMMNOl:;:ldkOOOkkkxxkkkkxdlc;;;cokXWMMMMMMMMMMMMMXko:::cldxOOOOkkkkxkkkxdoc;;:oONMMMMMMMMMMM
// MMMMMMMMMXd:;cx0K00Okkxxxxxxxxxxxxxxkkxl:;;ckXMMMMMMMMXxc;;ldOKK0OOkkkxxxxxxddxxxxkkko:,:dXMMMMMMMMM
// MMMMMMMXd,:xKXXK0OOkxxxxxxxxxxxdddxxxxxxkkdc;;oKWMMW0l;:oOKXKK00OOkkxxxxxxxollodddddxxkkl,,dXMMMMMMM
// MMMMMWk,,xKXXK0OOkxxxdddddxdddddddddxxxxxxkkko;'okkl':kKXXKK00OOkkkxdoc:;,'...'lddddddxxkko,;OWMMMMM
// MMMMNo'c0XXKK0Okxxxdc...';:Glodddxdddxxxxxxkkkko,..;xKXXXKK00kdlc;,'..    ...':ooooooodddxkx;'dNMMMM
// MMMNl.oKKKK0Okkxxdddc'..    ...',:Gloddxxxxxxkkkxxk0XXXXKK0x:..    ...';:cloooooooooooodddxxkc.oNMMM
// MMWd.l000OOkkxxdddddddolc:;,...     ..,lddxxxxxxxkOO0KKK00Od;..';:clloooooooooooooooooooodddxx:.dWMM
// MMO';kOOkkxxxxdddddddddddddddolc:;,'...:dddxxxxxxxxkOOOOOkkxdddd_________lloooooollllooooodddxd''0MM
// MWl.lkkxxxxdddddo:;;::ccclllooooddddooodddddddddxxxxxkkxxxdddd XXXXXXXXXXXX loolllllllloooooooo;.lWM
// MK;'dxdddddddddd:.    ...........'',,,;;;::cclllooodddxdddddd XXXXXXXXXXXXXX:lollllllllloooolllc.;XM
// MO''oddddddddddd;.   'xk, .cd,                 .......''',,,;',XX:. 'XXXXXXXX:llllllllllllllcccc.,0M
// M0''oooooooooooolc,. .:Coxxixl,.               .,;;,,.     .'.       ...',,;'.'',,,,;:llllcccccc.,0M
// MX;.loooooooooooool;'. .l0o'.oXx.              'odood:.    cXk. ,kx'                 ,ccccccccc:.:XM
// MWo.;ollllooooooooool,.  .cKk;'ckd'          ..;ooooo:.    .,GosiaIlu'              .;ccccccccc,.dWM
// MMK,.clllllllllloooollc'  .;,  .lc.        .,loooooool:,.    .ldl;:dOl..          .,,:cccccccc:.;KMM
// MMWk'.clccccclllllllllo:,,''........     .:clooooooooooc,..    .dXo..oGd.      .'';ccc:::::cc:.'OMMM
// MMMWk'.:cccccccccclllllllllolllllllccc:::clooooooooolooool,.    ...  .;'     ..,ccc::::::::c;.,OWMMM
// MMMMW0;.;ccc::ccccccccllllllllllllllllllllllllllllllllllllc::;;,,,''........'::::::::::::::,.;0MMMMM
// MMMMMMXl..:c::::::ccccccccclllllllllllllllllllllllllllllccccccccccccccc::::::::::::::::::;..oXMMMMMM
// MMMMMMMWO;.,:::::::::::ccccccccccclccllclllllllccccccccccccccccc:::::::::::::::::::::::;'.;OWMMMMMMM
// MMMMMMMMMNx,.,::::::::::::::ccc:,'',;:ccccccccccccccccccccccc::::::::::::::::::::;;::;'.;kNMMMMMMMMM
// MMMMMMMMMMMXd,.,:::::::::::::::'.;d;..,'.',,;:ccccc:::::::::::::::::::::::::;;:;;;:;'.,xNMMMMMMMMMMM
// MMMMMMMMMMMMMXd,.,:::::::::::::..xNk;xX0ko'.;;'..'',,;::::::::::::::::;;;;;;;;;;;;'.,dXMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMXd,.';::::::;::,.'ox:.cdddo':kxx:.,lc:,....',,;::::;;;;;;;;;;;;;;'.,dXMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMXd,.';;;:;;:;'.c00c,xkxd:.:ooo,.;ddd:. .........'',;;;;;;;;;;'.;xXMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMXx;..;;;;;;'..'...,,,,..,;;;...,,'.   ....       ...,;;;,..;xNMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMNk:..,;;;;;;;;;;;;;;;;;;;;;,,,,,,,,,,,,''''''''''',;,..:kNMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMNO:..,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;;;;'..cOWMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMW0l'.',;;,,,,,,,;;;;;;;;;;;;;;;;;;;,,,,,,;;,'.'l0WMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMWKo,.',,,,,,,,,,,,,,,;;;;;,,,,,,,,,,,,,,..,dXMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMXx;..',,,,,,,,,,,,,,,,,,,,,,,,,,,,'..;xXMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNk:..',,,,,,,,,,,,,,,,,,,,,,,,'..:kNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWOc..',,''''',,',,',,,,,,,'..c0WMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMW0l'..'''''''''''''','..'oKWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWKo'..''''''''''''..,dXMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMXx,......''''..;xXMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNk;........:kNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNOo:;;:o0WMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM  
//                                                  TO
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMWNXXKKKKKKKXXNWWMMMMMMMMMMMMMMMMMMMMMMMMMMMWNXKK00OOO000KXNWWMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMWNK0kkxxxxxxxxxxxxxkk0KNWMMMMMMMMMMMMMMMMMMMWX0OkxxdxxxxxxxxddxxkO0XWMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMWX0kdddxkOOO0000000OOOkxddxk0NWMMMMMMMMMMMMMWXOxddxkOO0000000000OOkkxddxOXWMMMMMMMMMMMM
// MMMMMMMMMMMWKkddxkO0000000OOOOO0000000OkxdxOKWMMMMMMMMMNKkddxkO00000OOOOOOOO00000OOkxddkKNMMMMMMMMMM
// MMMMMMMMMWKkddxkO00OOkkxxxddddxxxxkkOO00OOxxdk0NWMMMMNKkddxOOOOOkkxxxddddddxxxkkOOOOOkxddkKWMMMMMMMM
// MMMMMMMMNOddxkOOOOkxddooolloloooooodxxkkOOOOkxdx0XNX0xddkOOOOkxxdoooollllllooooddxkOOOOkxddONMMMMMMM
// MMMMMMWXkodxOOOkxddoolllllllllllllllooddxkOO0OkxdxxxdxkOOOkkxdoollllcccccllllllloodxkOOOOxdoxXMMMMMM
// MMMMMWXxodkOOkxdoolllllllc:,'....';cllloodxkOOOOOkkOOOOOkxxdoolllc;'......,:lllllllodxkOOOkdoxXMMMMM
// MMMMMXxldkOOkxdollllllllc'.        .,cllloodxxkOOOOOOkkxddooolll;.         .,clllllloodkOOOkdokNMMMM
// MMMMWkloxOOkxdollllllllc'            ,llllooodddxxxxxddoooollll:.           .;llllllllodkOOOxoo0WMMM
// MMMMKdldkOkkdoollllllll:.            .clllllooooooooooooollllll;             ,llllllllodxkOOkdlxXMMM
// MMMWOlldkOkxdolllllllllc'            'cllllllllllooooolllllllll:.           .;lllllllllodkOOkxoo0MMM
// MMMNxclxkkkxdollllllllll:.          ':llllllllllllllllllllllllll;.         .;llllllllllodxkOkxooOWMM
// MMMXd:ldkkxddoollllllllllc;'..  ..';cllllllllllllllllllllllllllllc,.......;clllllllllllodxkkkxolOWMM
// MMMNd:ldxkxxdoollllllllllllllc::ccllllllllllllllllllllllllllllllllllcccclllllllllllllloodxkkkdllOWMM
// MMMWk:coxxxddoollllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllloodxxxxolo0MMM
// MMMM0c:lodddooollllllllllllllllclllllllllllllllllllllllllllllllllllccccclllllllllllllloooddddlcxXMMM
// MMMMNd:cloooooollllllllllllc;'.....,:clllllllllllllllllllllllllc:,.......,cllllllllllloooooolclOWMMM
// MMMMM0l;:llllllllllllllllc;.         .;cllllllllllllllllllllll:.          .;llllllllllooooolccxNMMMM
// MMMMMWk:;:cllllllllllllll;.            .;cllllllllllllllllll:'.            .:llllllllllllllccdKMMMMM
// MMMMMMNx:;:ccccllllllllll,               .;cllllllllllllll:'.              .;llllllllllllcc:oKWMMMMM
// MMMMMMMNx:;::cccccccccccl;.                .;cllllllllll:'.                .:cclccccccccc::oKWMMMMMM
// MMMMMMMMNk:,;::ccccccccccc,.                 .;cllllll:'.                 .;ccccccccccc:::oKWMMMMMMM
// MMMMMMMMMWk:,,;::::::cccccc:'.                 .;clc:'.                 .,:cccccccc::::;:dXMMMMMMMMM
// MMMMMMMMMMW0l,,,;;;:::::::ccc:'.                 ....                 .,:c::::::::::;;;:xNMMMMMMMMMM
// MMMMMMMMMMMWXx;'',,;;;:::::::cc:'.                                  .,:c::::::::;;;;,,lONMMMMMMMMMMM
// MMMMMMMMMMMMMWKo;'',,,;;;::::::cc:'.                              .,:c:::::::;;;;,,,:xXWMMMMMMMMMMMM
// MMMMMMMMMMMMMMMW0o,.'',,;;;;:::::cc:'.                          .,:cc::::::;;;,,'';dKWMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMW0o,..',,;;;;:::::cc:,.                      .,:c::::::;;;;,,'':dKWMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMWKd:'.'',,;;;:::::cc:,.                  .,:c::::::;;;,,'',ckXWMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMNOl,..',,;;;;::::cc:,.              .,:cc:::::;;;,,'';o0NMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMWKx:'.'',,;;;:::::cc,.          .,:cc:::::;;;,,',cxXWMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMNOo;..',,;;;:::::cc;,......';:c::::::;;,,'';oONMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMWKx:'.'',,;;;::::cccccccccc:::::;;;,,'':dKWMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNOl,..'',,,;;;;;:::::::;;;;;,,,'',ckXWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWKxc'....'',,,,,,,,,,,,,'''.':d0NMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMW0dc'.................':oOXWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWKkoc,'........,:lx0NMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWNX0OOOOO0KNWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
                                                                                                                      
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import {MEMEMetadata} from "./utils/MEMEMetadata.sol";
import {ERC20} from "./utils/ERC20.sol";
import {BotProtector} from "./utils/BotProtector.sol";
import {IUniswapV2Factory} from "./interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "./interfaces/IUniswapV2Router02.sol";
import {ITokenFactoryBase} from "./interfaces/ITokenFactoryBase.sol";
import {ISwapper} from "./interfaces/ISwapper.sol";
import {OwnableHandshake} from "./utils/OwnableHandshake.sol";
import {Swapper} from "./utils/Swapper.sol";


contract MainToken is ERC20, OwnableHandshake, MEMEMetadata, BotProtector {
    //Dead Address for liquidity token check
    address public constant DEAD_ADDRESS = 0x000000000000000000000000000000000000dEaD;

    //Fee constants to caluclate fees 'amount * feeNominator / FEE_DENOMINATOR'
    uint32 public constant FEE_DENOMINATOR = 100000;
    //Max setable fee (1%)
    uint16 public constant MAX_FEE_NOMINATOR = 1000;
    //Default feeNominator 40000 = 40% for the launch
    uint16 public feeNominator = 400;

    //Token factories to create new tokens, are allowed to mint.
    mapping (address => bool) public isTokenFactory;

    //Accounts excluded from transaction fees. e.g. factories for creating tokens.
    mapping(address => bool) public feeExcluded;

    //Reflects the available supply which is not locked into created token liquidity.
    uint256 public availableSupply;
    //Reflects the suppy which is minted when a new token is created.
    uint256 public virtualSupply;


    //Address of the Swapper contract
    address public swapper;

    //Account receiving transaction fees.
    address public feeAccount;

    //Address of contract creating the start liquidity
    address public liquidityAdder;
    //Bool to check if start liquidity are deployed
    bool public startLiquiditySet;

    //Constant addresses for the first factory
    // ETH
    // address public constant UNISWAP_ROUTER = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D;
    // address public constant UNISWAP_FACTORY = 0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f;
    // address public constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;


    // Testnet
    address public constant UNISWAP_ROUTER = 0xD99D1c33F9fC3444f8101754aBC46c52416550D1;
    address public constant UNISWAP_FACTORY = 0x6725F303b657a9451d8BA641348b6761A6CC7a17;
    address public constant WETH = 0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd;

    // BASE
    // address public constant UNISWAP_ROUTER = 0x4752ba5DBc23f44D87826276BF6Fd6b1C372aD24;
    // address public constant UNISWAP_FACTORY = 0x8909Dc15e40173Ff4699343b6eB8132c65e18eC6;
    // address public constant WETH = 0x4200000000000000000000000000000000000006;

    event TokenFactorySet(address tokenFactory, bool state);
    event NewPairCreated(address pairedToken);
    event ChangedFee(uint newFeeNominator);
    event ChangedFeeAccount(address newFeeAccount);
    event ChangedFeeExcludedAccount(address account, bool state);
    event ResetVirtualSupply();
    event SwapperChanged(address oldSwapper, address newSwapper);

    constructor(address initialOwner_, string memory name_, string memory symbol_, address tokenFactory0_, address tokenFactory1_, address tokenFactory2_, address liquidityManager_, uint salt_, Metadata memory metadata_) 
        ERC20(name_, symbol_)
        MEMEMetadata(msg.sender, metadata_)
        BotProtector(address(this)) 
        OwnableHandshake(initialOwner_) {
            _mint(msg.sender, 42e24);

            isTokenFactory[tokenFactory0_] = true;
            _changeUnlimitedAccount(tokenFactory0_, true);
            feeExcluded[tokenFactory0_] = true;

            isTokenFactory[tokenFactory1_] = true;
            _changeUnlimitedAccount(tokenFactory1_, true);
            feeExcluded[tokenFactory1_] = true;

            isTokenFactory[tokenFactory2_] = true;
            _changeUnlimitedAccount(tokenFactory2_, true);
            feeExcluded[tokenFactory2_] = true;

            feeExcluded[liquidityManager_] = true;
            feeExcluded[msg.sender] = true;
            liquidityAdder = liquidityManager_;

            feeAccount = liquidityManager_;
            availableSupply = totalSupply();
            _changeUnlimitedAccount(address(this), true);

            _changeUnlimitedAccount(liquidityManager_, true);
            _changeUnlimitedAccount(msg.sender, true);

            emit TokenFactorySet(tokenFactory0_, true);
            emit TokenFactorySet(tokenFactory1_, true);
            emit TokenFactorySet(tokenFactory2_, true);

            emit ChangedFeeExcludedAccount(tokenFactory0_, true);
            emit ChangedFeeExcludedAccount(tokenFactory1_, true);
            emit ChangedFeeExcludedAccount(tokenFactory2_, true);            
            emit ChangedFeeExcludedAccount(liquidityManager_, true);            
            emit ChangedFeeExcludedAccount(msg.sender, true);            
        }


    /**
     * @dev Allows the owner to change the swapper address.
     *
     * @param newSwapper The new swapper address.
     */
    function changeSwapper(address newSwapper) external onlyOwner {
        emit SwapperChanged(swapper, newSwapper);
        if (newSwapper != address(0)) {
            ISwapper(newSwapper).tradeState();
            ISwapper(newSwapper).feeNominatorToken();
        }
        if (swapper != address(0)) {
            feeExcluded[swapper] = false;
            _changeUnlimitedAccount(swapper, false);
        }
        swapper = newSwapper;
        _changeUnlimitedAccount(newSwapper, true);
        feeExcluded[newSwapper] = true;
    }

    /**
     * @dev Allows the owner to set or remove an account's fee exclusion status.
     *
     * Excluded accounts will not be charged transaction fees when transferring tokens.
     *
     * @param account_ The address of the account to update.
     * @param state_ A boolean indicating whether the account should be excluded from fees (`true`) or not (`false`).
     */
    function changeFeeExcludedAccount(address account_, bool state_) external onlyOwner {
        _changeFeeExcludedAccount(account_, state_);
    }

    /**
     * @dev Internal function to change the fee exclusion state of an account.
     *
     * @param account_ The address of the account to update.
     * @param state_ A boolean indicating whether the account should be excluded from fees (`true`) or not (`false`).
     */
    function _changeFeeExcludedAccount(address account_, bool state_) internal {
        feeExcluded[account_] = state_;
        emit ChangedFeeExcludedAccount(account_, state_);
    }

    /**
     * @dev Allows the owner to designate an account as unlimited or not. Unlimited accounts are exempt 
     *      from transfer limits enforced by the `BotProtector` mechanism.
     *
     * @param account_ The address of the account to update.
     * @param unlimited_ A boolean indicating whether to set the account as unlimited (`true`) or not (`false`).
     */
    function changeUnlimitedAccount(address account_, bool unlimited_) external onlyOwner {
        _changeUnlimitedAccount(account_, unlimited_);
    }

    /**
     * @dev Allows the owner to change the fee exclusion state and the unlimited state of multiple accounts.
     *
     * @param accounts_ An array of addresses of the accounts to update.
     * @param state_ A boolean indicating whether to set the accounts as fee excluded (`true`) or not (`false`).
     */
    function changeFeeExcludedAccountAndUnlimited(address[] calldata accounts_, bool state_) external onlyOwner {
        for (uint i = 0; i < accounts_.length; i++) {
            _changeFeeExcludedAccount(accounts_[i], state_);
            _changeUnlimitedAccount(accounts_[i], state_);
        }
    }

    /**
     * @dev Accepts the ownership transfer.
     * 
     * NOTE: Remove the fee exclusion of the old owner and set the new owner to fee excluded.
     *       The 'newOwner' has to call 'acceptOwnership'.
     *       If 'submitTransferOwnership' is called before the old 'newOwner' accepted the ownership
     *       the new 'newOwner' can accept the old one not anymore.
     */
    function acceptOwnership() public override {
        require(msg.sender == submittedOwner(), "LuvBomb: Only the 'submittedOwner' can accept the ownership.");
        feeExcluded[owner()] = false;
        _transferOwnership(submittedOwner());
        feeExcluded[submittedOwner()] = true;
        emit OwnershipTransferAccepted();
    }

    /**
     * @dev Allows the owner to change the ownership after deployment.
     * 
     * NOTE: Only the owner can call this function.
     *       The 'newOwner' has to call 'acceptOwnership' after the deployment.
     */
    function changeOwnershipAfterDeployment(address newOwner) external override onlyOwner {
        require(!firstOverTake, "LuvBomb: Overtake already happen.");
        _transferOwnership(newOwner);
        firstOverTake = true;
    }

     /**
     * @dev Allows the owner to change the transaction fee percentage.
     *
     * The fee is set as a fraction of the total transfer amount, calculated using `feeNominator / FEE_DENOMINATOR`.
     *
     * Requirements:
     *
     * - The caller must be the owner of the contract.
     * - The new `feeNominator` must be less than or equal to `MAX_FEE_NOMINATOR` (1%).
     *
     * @param feeNominator_ The new fee nominator value, representing the percentage of the transfer amount to be taken as a fee.
     */
    function changeFee(uint16 feeNominator_) external onlyOwner {
        require(feeNominator_ <= MAX_FEE_NOMINATOR, "LuvBomb: Max 'feeNominator' is 1000 or 1%.");
        feeNominator = feeNominator_;
        emit ChangedFee(feeNominator);
    }


    /**
     * @dev Allows the owner to change the account where transaction fees are collected.
     *
     * The `feeAccount` is the address that will receive the transaction fees collected by the contract.
     *
     * @param feeAccount_ The new fee account address.
     */
    function changeFeeAccount(address feeAccount_) external onlyOwner {
        feeAccount = feeAccount_;
        emit ChangedFeeAccount(feeAccount);
    }

     /**
     * @dev Allows the owner to change the state of a token factory, enabling or disabling it.
     *
     * The function sets the `isTokenFactory` status and changes the unlimited account status of the provided token factory address.
     * The fee exclusion status of the token factory address is also updated accordingly.
     *
     *
     * @param tokenFactoryAdr_ The address of the token factory to update.
     * @param state_ A boolean indicating whether the token factory should be enabled (`true`) or disabled (`false`).
     */
    function changeTokenFactoryState(address tokenFactoryAdr_, bool state_) external onlyOwner {
        isTokenFactory[tokenFactoryAdr_] = state_;
        _changeUnlimitedAccount(tokenFactoryAdr_, state_);
        feeExcluded[tokenFactoryAdr_] = state_;

        emit ChangedFeeExcludedAccount(tokenFactoryAdr_, state_);
        emit TokenFactorySet(tokenFactoryAdr_, state_);
    }

    /**
     * @dev Activates limits by setting specific accounts as unlimited and marking the contract as active.
     *
     * This function is designed to be called by the `liquidityAdder` contract to remove limits from the 'BotProtection'
     * for the Uniswap Pool and the Batchbuy.
     * 
     * Note Once activated, the contract cannot be re-activated.
     *
     * @param uniswapV2pool_ The address of the Uniswap V2 pool to be marked as unlimited.
     */
    function setStartUnlimitedAccounts(address uniswapV2pool_) external {
        require(msg.sender == liquidityAdder, "LuvBomb: Only the liquidityAdder contract can call this.");
        require(!startLiquiditySet, "LuvBomb: Already activated.");
        _changeUnlimitedAccount(uniswapV2pool_, true);
        startLiquiditySet = true;
    }

    /**
     * @dev Moves a `value` amount of tokens from `from` to `to`.
     *
     * This internal function is equivalent to {transfer}, and can be used to
     * e.g. implement automatic token fees, slashing mechanisms, etc.
     *
     * Emits a {Transfer} event.
     *
     * NOTE: Changed this function to use the 'proctectAgainsBots' modifier. And add a transaction fee.
     */
    function _transfer(address from, address to, uint value) internal override protectAgainsBots(from, to){
        uint amountAfterFee = value;

        uint _feeNominator = feeNominator; 

        if (swapper != address(0)) {
            bool tradeState = ISwapper(swapper).tradeState();
            if (tradeState) {
                _feeNominator = ISwapper(swapper).feeNominatorToken();
                if (feeNominator > MAX_FEE_NOMINATOR) {
                    _feeNominator = MAX_FEE_NOMINATOR;
                }
            }
        }

        if (_feeNominator > 0 && !(feeExcluded[from] || feeExcluded[to])) {
            uint fee = value * _feeNominator / FEE_DENOMINATOR;

            amountAfterFee = value - fee;
            super._transfer(from, feeAccount, fee);
        }

        super._transfer(from, to, amountAfterFee);
    }


    /**
     * @dev Allows a verified token factory to mint tokens, add liquidity to the Uniswap pool,
     * and optionally trigger a first buy. This function is used to facilitate the initial
     * distribution and liquidity setup of a new token.
     * 
     * @param mainTokenAmount_ The amount of main tokens to mint.
     * @param forToken_ The address of the token for which liquidity is being added.
     * @param firstBuyAmount_ The amount of the first buy to trigger, if any.
     * @param to_ The address to receive the tokens from the first buy.
     * 
     * NOTE: This function conducts a safety check to ensure that the pair token supply is fully burned,
     * and that the new token supply is entirely placed in the liquidity pool.
     * It prevents malicious factory from adding liquidity to some degree. Make sure that the added factories have a compatible uniswapV2Factory 
     * set as 'uniswapFactoryAdr' in the 'TokenFactoryBase' contract.
     * 
     * WARNING: Only addresses listed in `isTokenFactory` can call this function. The minting
     * amount must not exceed `MAX_MINT_AMOUNT` to prevent over-minting.
     */
    function factoryMint(uint mainTokenAmount_, address forToken_, uint firstBuyAmount_, address to_) external {
        address sender = msg.sender;    
        require(isTokenFactory[sender], "LuvBomb: Only the tokenFactory can call this function.");
        require(mainTokenAmount_ <= MAX_MINT_AMOUNT, "LuvBomb: you can only mint MAX_MINT_AMOUNT tokens.");

        _mint(sender, mainTokenAmount_);
        virtualSupply += mainTokenAmount_;

        //Max supply is 2^256 - 1 - 5 * MAX_MINT_AMOUNT, so we don't need to check for overflow.
        if (MAX_SUPPLY < virtualSupply) {
            virtualSupply = mainTokenAmount_;
            _resetTotalSupply(mainTokenAmount_ + availableSupply);
            emit ResetVirtualSupply();
        }

        ITokenFactoryBase(sender).addLiquidity(forToken_, mainTokenAmount_);

        //Safety check to prevent malicious factory adding   
        address pairFactory = ITokenFactoryBase(sender).uniswapFactoryAdr();
        address newPair = IUniswapV2Factory(pairFactory).getPair(address(this), forToken_);
        uint pairSupply = IERC20(newPair).totalSupply();
        uint newTokenSupply = IERC20(forToken_).totalSupply();
        uint pairBalance = IERC20(forToken_).balanceOf(newPair);
        uint zeroBalance = IERC20(newPair).balanceOf(address(0));

        _changeUnlimitedAccount(newPair, true);

        require(zeroBalance == pairSupply, "LuvBomb: The pair token supply is not completly burned.");
        require(pairBalance == newTokenSupply, "LuvBomb: The new token supply is not completly in the liquidity pool.");

        if (firstBuyAmount_ > 0) {
            ITokenFactoryBase(msg.sender).triggerFirstBuy(forToken_, firstBuyAmount_, to_);
        }
    }
}