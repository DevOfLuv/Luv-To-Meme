// SPDX-License-Identifier: MIT
// OpenZeppelin Contracts (last updated v5.0.0) (token/ERC20/ERC20.sol)

pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import {SideToken_CLOG} from "./SideToken_CLOG.sol";
import {IUniswapV2Factory} from "./interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "./interfaces/IUniswapV2Router02.sol";
import {IMainToken} from "./interfaces/IMainToken.sol";
import {ISideToken_CLOG} from "./interfaces/ISideToken_CLOG.sol";

import {TokenFactoryBase} from "./TokenFactoryBase.sol";


contract TokenFactory03 is TokenFactoryBase {

    constructor(address initialOwner_) TokenFactoryBase(initialOwner_){}

    /**
     * @dev Creates a new CLOG token with the specified parameters and adds liquidity for it.
     * This function sets up the new token, configures its clogging parameters, and manages
     * initial liquidity provisioning and tracking.
     * 
     * @param name_ The name of the new CLOG token.
     * @param symbol_ The symbol of the new CLOG token.
     * @param decimals_ The number of decimals the token uses.
     * @param totalSupply_ The initial total supply of the new token.
     * @param mediaAccount_ The address associated with media accounts or promotion.
     * @param mainTokenAmount_ The amount of main tokens to use for liquidity.
     * @param feeAccount_ The address where fees or specific controls are managed.
     * @param salt_ A unique salt value used for deploying the new token.
     * @param firstBuyAmount_ The amount for the first buy to be triggered.
     * @param contractStruct_ The clogging parameters struct for configuring the new token's behavior.
     * @param metadata_ The metadata associated with the new token, containing additional configuration.
     * 
     * NOTE: This function creates a new `SideToken_CLOG` instance and mints main tokens for it,
     * setting up initial liquidity on Uniswap. It also sets the start pair for the token, ensuring
     * proper pair management.
     */
    function createCLOGToken(
        string memory name_, string memory symbol_, uint8 decimals_, uint totalSupply_, address mediaAccount_, uint mainTokenAmount_, address feeAccount_, uint salt_, uint firstBuyAmount_,
        SideToken_CLOG.ClogParams memory contractStruct_,  SideToken_CLOG.Metadata memory metadata_
    ) external {
        SideToken_CLOG newToken = new SideToken_CLOG(
            name_, 
            symbol_, 
            decimals_, 
            totalSupply_, 
            mediaAccount_, 
            feeAccount_, 
            salt_,
            contractStruct_,            
            uniswapRouterAdr,
            metadata_,
            mainTokenAdr
        );
        IMainToken(mainTokenAdr).factoryMint(mainTokenAmount_, address(newToken), firstBuyAmount_, msg.sender);

        newToken.setStartPair(createdTokenPair[address(newToken)]);

        _setValues(address(newToken), TokenType.CLOG);
    }
}