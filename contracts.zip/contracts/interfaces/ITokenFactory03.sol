// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {ITokenFactoryBase} from "./ITokenFactoryBase.sol";
import {SideToken_CLOG} from "../SideToken_CLOG.sol";

interface ITokenFactory03 is ITokenFactoryBase {
    //Functions
    function createCLOGToken(
        string memory name_,
        string memory symbol_,
        uint8 decimals_,
        uint totalSupply_,
        address mediaAccount_,
        uint mainTokenAmount_,
        address feeAccount_,
        uint salt_,
        uint firstBuyAmount_,
        SideToken_CLOG.ClogParams memory contractStruct_,
        SideToken_CLOG.Metadata memory metadata_
    ) external;
}