// contracts/utils/BotProtector.sol
interface IBotProtector {
    function lastTransaction(address account) external view returns (uint);
    function unlimitedTransactionAccount(address toCheck_) external view returns (bool);
    event UnlimitedAccountChange(address account, bool unlimited);
}