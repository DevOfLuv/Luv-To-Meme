// SPDX-License-Identifier: MIT
pragma solidity >=0.5.0;

import "./IBotProtector.sol";

interface IMainToken is IBotProtector {
    function factoryMint(uint mainTokenAmount_, address forToken_, uint firstBuyAmount_, address to_) external;
    function setStartUnlimitedAccounts(address uniswapV2pool_) external;
    function unlimitedTransactionAccount(address toCheck_) external view returns(bool);
    function feeExcluded(address toCheck_) external view returns(bool);
    function feeAccount() external view returns (address);
    function feeNominator() external view returns (uint);
    function FEE_DENOMINATOR() external view returns (uint);
    function UNISWAP_FACTORY() external view returns(address);
    function UNISWAP_ROUTER() external view returns(address);
    function WETH() external view returns(address);

    event TokenFactorySet(address tokenFactory, bool state);
    event NewPairCreated(address pairedToken);
    event ChangedFee(uint newFeeNominator);
    event ChangedFeeAccount(address newFeeAccount);
    event ChangedFeeExcludedAccount(address account, bool state);
    event ResetVirtualSupply();
    event SwapperChanged(address oldSwapper, address newSwapper);
}
