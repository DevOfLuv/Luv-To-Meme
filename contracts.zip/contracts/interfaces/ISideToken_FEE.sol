// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {ISideToken_ERC20} from "./ISideToken_ERC20.sol";

interface ISideToken_FEE is ISideToken_ERC20 {
    //Variables
    function feeAccount() external view returns (address);
    function FEE_DENOMINATOR() external pure returns (uint16);
    function feeNominator() external view returns (uint16);

    //Functions
    function changeFeeAccount(address newFeeAccount_) external;
    
    //Events
    event FeeAccountChanged(address oldAccount, address newAccount);
}