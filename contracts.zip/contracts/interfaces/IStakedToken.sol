// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

interface IStakedToken is IERC20 {
    //Constants
    function STAKING_CONTRACT_ADDRESS() external view returns (address);

    //Functions
    function mint(address to_, uint amount_) external;
    function burn(address from_, uint amount_) external;
}