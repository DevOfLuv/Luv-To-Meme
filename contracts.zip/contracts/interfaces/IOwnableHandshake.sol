// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IOwnableHandshake {
    struct Metadata {
        string uri;
        string logo;
        string website;
        string telegram;
        string twitter;
        string discord;
    }
    
    function owner() external view returns (address);
    function submittedOwner() external view returns (address);
    function firstOverTake() external view returns (bool);

    function renounceOwnership() external;
    function changeOwnershipAfterDeployment(address newOwner) external;
    function submitTransferOwnership(address newOwner) external;
    function acceptOwnership() external;

    error OwnableUnauthorizedAccount(address account);
    error OwnableInvalidOwner(address owner);

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event OwnershiptTransferSubmitted(address ownerSubmitted);
    event OwnershipTransferAccepted();
}