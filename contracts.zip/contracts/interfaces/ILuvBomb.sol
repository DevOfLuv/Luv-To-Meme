// contracts/interfaces/ITokenFactoryBase.sol

// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

interface ITokenFactoryBase {
    // Enum for Token Types
    enum TokenType {
        ERC20,
        FEE,
        CLOG
    }

    // Events
    event NewTokenCreated(address indexed newToken, TokenType tokenType, uint tokenIndex, uint creationBlock, address pairAdr);
    event ChangedFeeAccount(address indexed newFeeAccount);
    event ChangedFeeNominator(uint newFeeNominator);
    event ChangeActivity(bool isActive);

    // Functions
    function changeActivity(bool state_) external;
    function changeMediaAccountForToken(address token_, address newMediaAccount_) external;
    function setFeeAccount(address feeAccount_) external;
    function changeFeeNominator(uint feeNominator_) external;
    function setMainTokenAdr(address mainTokenAdr_) external;
    function addLiquidity(address forTokenAdr_, uint mainTokenAmount_) external;
    function triggerFirstBuy(address newTokenAdr_, uint firstBuyAmount_, address to_) external;
}