// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

interface IMEMEMetadata {
    //Structs
    struct Metadata {
        string uri;
        string logo;
        string website;
        string telegram;
        string twitter;
        string discord;
    }

    //Variables
    function mediaAccount() external view returns (address);
    function factory() external view returns (address);
    function metadata() external view returns (Metadata memory);

    //Functions
    function changeMediaAccount(address newMediaAccount_) external;
    function changeUri(string calldata newUri_) external;
    function changeLogo(string calldata newLogo_) external;
    function changeWebsite(string calldata newWebsite_) external;
    function changeTelegram(string calldata newTelegram_) external;
    function changeTwitter(string calldata newTwitter_) external;
    function changeDiscord(string calldata newDiscord_) external;
    function changeAllMedia(Metadata memory metadata_) external;

    //Events
    event MediaAccountChanged(address newMediaAccount);
    event UriChanged(string newLink);
    event LogoChanged(string newLink);
    event WebsiteChanged(string newLink);
    event TelegramChanged(string newLink);
    event TwitterChanged(string newLink);
    event DiscordChanged(string newLink);
}