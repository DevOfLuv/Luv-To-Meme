// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {ISideToken_ERC20} from "./ISideToken_ERC20.sol";

interface ISideToken_CLOG is ISideToken_ERC20 {
    //Structs
    struct ClogParams {
        uint16 startFeeNominator;
        uint16 endFeeNominator;
        uint maxWalletAmountStart;
        uint maxWalletAmountEnd;
        uint txnCountLimit;
    }

    //Constants
    function FEE_DENOMINATOR() external pure returns (uint16);

    //Variables
    function startPair() external view returns (address);
    function uniswapRouterAdr() external view returns (address);
    function feeAccount() external view returns (address);
    function txnCount() external view returns (uint);
    function contractStruct() external view returns (ClogParams memory);

    //Functions
    function setStartPair(address startPair_) external;
    function getCurrentNominator() external view returns (uint16);
    function removeLimits() external;
    function manualSwap(uint toSellAmount) external;
    function changeFeeAccount(address newFeeAccount_) external;

    //Events
    event FeeAccountChanged(address oldAccount, address newAccount);
}