// contracts/interfaces/ISwapper.sol
pragma solidity ^0.8.0;

interface ISwapper {
    //Variables
    function tradeState() external view returns (bool);
    function feeNominatorToken() external view returns (uint);
    function feeNominatorWhithoutRef() external view returns (uint);
    function feeNominatorWhithRef() external view returns (uint);

    //Functions
    function changeFeeNominatorToken(uint newFeeNominator) external;
    function changeFeeNominatorWhithoutRef(uint newFeeNominator) external;
    function changeFeeNominatorWhithRef(uint newFeeNominator) external;
    function addWhitelist(address[] memory addresses) external;
    function createRefId(string calldata refId) external;
    function removeRefId(address user) external;
    function removeRefAndWhitelist(address user) external;
    function swapIn(string calldata refId, address[] memory path, uint256 minAmountOut) external payable;
    function swapOut(string calldata refId, address[] memory path, uint amountIn, uint256 minAmountOut) external;

    //Events
    event ChangedFeeNominator(uint oldFeeNominator, uint newFeeNominator);
    event ChangedFeeNominatorWhithRef(uint oldFeeNominator, uint newFeeNominator);
    event ChangedFeeNominatorWhithoutRef(uint oldFeeNominator, uint newFeeNominator);
    event ChangedDefaultRefReceiver(address oldDefaultRefReceiver, address newDefaultRefReceiver);
    event ChangedUnlimitedAccount(address account, bool unlimited);
    event RefReceived(address indexed refReceiver, uint amount);
    event RefIdAdded(address indexed user, string refId);
    event RefIdRemoved(address indexed user);
}