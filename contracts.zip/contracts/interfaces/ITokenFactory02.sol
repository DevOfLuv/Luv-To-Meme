// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {ITokenFactoryBase} from "./ITokenFactoryBase.sol";
import {SideToken_FEE} from "../SideToken_FEE.sol";

interface ITokenFactory02 is ITokenFactoryBase {
    //Functions
    function createFEEToken(
        string memory name_,
        string memory symbol_,
        uint8 decimals_,
        uint totalSupply_,
        address mediaAccount_,
        uint mainTokenAmount_,
        address feeAccount_,
        uint16 feeNominator_,
        uint salt_,
        uint firstBuyAmount_,
        SideToken_FEE.Metadata memory metadata_
    ) external;
}