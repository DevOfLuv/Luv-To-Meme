// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {IERC721} from "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import {IOwnableHandshake} from "./IOwnableHandshake.sol";

interface IStakingNFT is IERC721, IOwnableHandshake {
    //Structs
    struct NFTInfo {
        uint alreadyClaimed;
        uint claimable;
        uint claimableAt;
    }

    //Variables
    function LOCK_TIME() external view returns (uint);
    function mainTokenAdr() external view returns (address);
    function nftInfo(uint tokenId) external view returns (NFTInfo memory);
    function totalSupply() external view returns (uint);
    function totalClaimableAfterLock() external view returns (uint);
    function baseURI() external view returns (string memory);
    function iStakedToken() external view returns (address);
    function stakedTokenAddress() external view returns (address);

    //Functions
    function changeBaseURI(string memory baseURI_) external;
    function stake(uint amount_) external;
    function unstake(uint amount_) external;
    function claimableNow(uint tokenId_) external view returns (uint claimableAmount);
    function claim(uint tokenId_) external;
    function withdraw(uint tokenId_) external;

    //Events
    event BaseURIChanged(string newBaseURI);
    event WithdrawNFTCreated(address user, uint nftId, uint claimableAmount, uint claimableAtTimestamp);
    event Withdrawl(address user, uint nftId, uint amount);
    event Stake(address user, uint amount);
}