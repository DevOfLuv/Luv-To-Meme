// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {ITokenFactoryBase} from "./ITokenFactoryBase.sol";
import {SideToken_ERC20} from "../SideToken_ERC20.sol";

interface ITokenFactory01 is ITokenFactoryBase {
    //Functions
    function createERC20Token(
        string memory name_,
        string memory symbol_,
        uint8 decimals_,
        uint totalSupply_,
        address mediaAccount_,
        uint mainTokenAmount_,
        uint salt_,
        uint firstBuyAmount_,
        SideToken_ERC20.Metadata memory metadata_
    ) external;
}