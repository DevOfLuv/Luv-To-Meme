// SPDX-License-Identifier: MIT
pragma solidity >=0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IMainToken} from "./IMainToken.sol";
import {IMEMEMetadata} from "./IMEMEMetadata.sol";

interface ISideToken_ERC20 is IERC20, IMEMEMetadata {
    //Variables
    function iMainToken() external view returns (IMainToken);
    function lastTransactionOfAccount(address account) external view returns (uint);
    function decimals() external view returns (uint8);
    function salt() external view returns (uint);
    function tokenFactory() external view returns (address);
}
