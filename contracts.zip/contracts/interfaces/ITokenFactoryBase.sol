// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {IOwnableHandshake} from "./IOwnableHandshake.sol";

interface ITokenFactoryBase is IOwnableHandshake {
    //Constants
    function DEAD_ADDRESS() external pure returns (address);
    function FEE_DONOMINATOR() external pure returns (uint);

    //Variables
    function feeNominator() external view returns (uint);
    function isActive() external view returns (bool);
    function feeAccount() external view returns (address);
    function mainTokenAdr() external view returns (address);
    function uniswapFactoryAdr() external view returns (address);
    function uniswapRouterAdr() external view returns (address);
    function batchTransferAdr() external view returns (address);
    function createdToken(uint index) external view returns (address);
    function createdTokenPair(address token) external view returns (address);
    function createdTokenLength() external view returns (uint);

    //Functions
    function changeActivity(bool state_) external;
    function changeMediaAccountForToken(address token_, address newMediaAccount_) external;
    function setFeeAccount(address feeAccount_) external;
    function changeFeeNominator(uint feeNominator_) external;
    function setMainTokenAdr(address mainTokenAdr_) external;
    function addLiquidity(address forTokenAdr_, uint mainTokenAmount_) external;
    function triggerFirstBuy(address newTokenAdr_, uint firstBuyAmount_, address to_) external;

    //Events
    event NewFEETokenCreated(address newToken);
    event NewERC20TokenCreated(address newToken);
    event NewCLOGTokenCreated(address newToken);
    event ChangedFeeAccount(address newFeeAccount);
    event ChangedFeeNominator(uint newFeeNominator);
    event ChangeActivity(bool isActive);
}