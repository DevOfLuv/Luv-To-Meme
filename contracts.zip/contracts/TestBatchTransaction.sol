// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;


import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";


import "hardhat/console.sol";

contract BatchTransaction {
    using SafeERC20 for IERC20;

    constructor() {}

    function transferBatch(address[] calldata addresses_, uint[] calldata amounts_, address token_, uint totalAmount_) external {
        require(addresses_.length == amounts_.length, "BatchTransaction: The given arrays 'addresses_' and 'amounts_' need to have the same length.");

        uint checkSum;
        IERC20(token_).safeTransferFrom(msg.sender, address(this), totalAmount_);

        for (uint i = 0; i < addresses_.length; i++) {
            IERC20(token_).safeTransfer(addresses_[i], amounts_[i]);
            checkSum += amounts_[i];
        }

        require(checkSum == totalAmount_, "BatchTransaction: The 'totalAmount_' have to be the sum of all amounts_");
    }
    
}