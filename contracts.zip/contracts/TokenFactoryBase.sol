// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import {IUniswapV2Factory} from "./interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "./interfaces/IUniswapV2Router02.sol";
import {IMainToken} from "./interfaces/IMainToken.sol";
import {ISideToken_CLOG} from "./interfaces/ISideToken_CLOG.sol";
import {OwnableHandshake} from "./utils/OwnableHandshake.sol";


interface ITokenMedia {
    function changeMediaAccount(address newMediaAccount_) external;
}

contract TokenFactoryBase is OwnableHandshake{

    enum TokenType {
        ERC20,
        FEE,
        CLOG
    }

    uint constant public FEE_DONOMINATOR = 10000;

    uint public feeNominator = 0;

    bool public isActive = true;

    address public feeAccount;
    address public mediaAccount;

    address public mainTokenAdr;
    address public uniswapFactoryAdr;
    address public uniswapRouterAdr;

    address[] public createdToken;
    mapping(address => address) public createdTokenPair;
    mapping(address => uint) public tokenIndex;
    mapping(address => uint) public creationBlock;
    uint public createdTokenLength;

    event NewTokenCreated(address newToken, TokenType tokenType, uint tokenIndex, uint creationBlock, address pairAdr);
    event ChangedFeeAccount(address newFeeAccount);
    event ChangedFeeNominator(uint newFeeNominator);
    event ChangeActivity(bool isActive);
    event ChangedMediaAccount(address newMediaAccount);

    modifier onlyMediaAccountOrOwner() {
        require(mediaAccount == msg.sender || msg.sender == owner(), "TokenFactoryBase: Only the media account or the owner can call this function.");
        _;
    }

    constructor(address initialOwner_) OwnableHandshake(initialOwner_) {
        mediaAccount = initialOwner_;
    }

    function setMediaAccount(address mediaAccount_) external onlyMediaAccountOrOwner {
        mediaAccount = mediaAccount_;
        emit ChangedMediaAccount(mediaAccount_);
    }

    /**
     * @dev Changes the activity state of the token factory.
     *
     * @param state_ The new activity state to set.
     */
    function changeActivity(bool state_) external onlyOwner {
        isActive = state_;
        emit ChangeActivity(isActive);
    }

    /**
     * @dev Changes the media account for a specific token.
     *
     * @param token_ The address of the token to change the media account for.
     * @param newMediaAccount_ The new media account address to set.
     */
    function changeMediaAccountForToken(address token_, address newMediaAccount_) external onlyMediaAccountOrOwner {
        ITokenMedia(token_).changeMediaAccount(newMediaAccount_);
    }

    /**
     * @dev Internal function to set values for a newly created token.
     *
     * @param newToken_ The address of the newly created token.
     */
    function _setValues(address newToken_, TokenType tokenType_) internal {
        tokenIndex[newToken_] = createdTokenLength;
        createdTokenLength++;
        creationBlock[newToken_] = block.number;
        createdToken.push(newToken_);
        createdTokenPair[newToken_] = IUniswapV2Factory(uniswapFactoryAdr).getPair(newToken_, mainTokenAdr);
        emit NewTokenCreated(newToken_, tokenType_, createdTokenLength-1, block.number, createdTokenPair[newToken_]);
    }

    /**
     * @dev Changes the fee account for the token factory.
     *
     * @param feeAccount_ The new fee account address to set.
     */
    function setFeeAccount(address feeAccount_) external onlyOwner {
        feeAccount = feeAccount_;
        emit ChangedFeeAccount(feeAccount);
    }

    /**
     * @dev Changes the fee nominator for the token factory.
     *
     * @param feeNominator_ The new fee nominator to set.
     */
    function changeFeeNominator(uint feeNominator_) external onlyOwner {
        require(feeNominator_ <= 500, "TokenFactoryBase: max fee nominator is 500 (5%).");
        feeNominator = feeNominator_;
        emit ChangedFeeNominator(feeNominator);
    }

    /**
     * @dev Internal function to calculate and send fees from an amount.
     *
     * @param amount_ The amount to calculate fees from.
     * @return fee The calculated fee amount.
     * @return amountAfterFee The amount after deducting the fee.
     */
    function _calculateAndSendFees(uint amount_) internal returns(uint fee, uint amountAfterFee) {
        if (feeNominator > 0) {
            fee = amount_ * feeNominator / FEE_DONOMINATOR;
            amountAfterFee = amount_ - fee;
            IERC20(mainTokenAdr).transfer(feeAccount, fee);
        } else {
            amountAfterFee = amount_;
        }
    }

    /**
     * @dev Sets the address of the main token and initializes the Uniswap factory and router addresses.
     * This function can only be called once, as it requires the `mainTokenAdr` to be unset.
     * 
     * @param mainTokenAdr_ The address of the main token to be set.
     * 
     * NOTE: This function initializes the Uniswap addresses by fetching them from the main token,
     * ensuring that the token factory is correctly configured for liquidity operations.
     */
    function setMainTokenAdr(address mainTokenAdr_) external {
        require(mainTokenAdr == address(0), "TokenFactoryBase: mainTokenAdr already set.");
        mainTokenAdr = mainTokenAdr_;
        uniswapFactoryAdr = IMainToken(mainTokenAdr).UNISWAP_FACTORY();
        uniswapRouterAdr = IMainToken(mainTokenAdr).UNISWAP_ROUTER();
    }

    /**
     * @dev Adds liquidity to the Uniswap pool for a specified token pair. This function transfers
     * tokens to the liquidity pool and sets approvals for the Uniswap router to manage the tokens.
     * 
     * @param forTokenAdr_ The address of the token to add liquidity for.
     * @param mainTokenAmount_ The amount of main tokens to add to the liquidity pool.
     * 
     * NOTE: This function can only be called by the main token address to ensure control over
     * liquidity provisioning.
     * 
     * WARNING: Ensure that the contract holds a sufficient balance of the tokens to add liquidity,
     * otherwise the transaction will fail.
     * The LP tokens will get locked in the zero address.
     */
    function addLiquidity(address forTokenAdr_, uint mainTokenAmount_) external {
        require(isActive, "TokenFactoryBase: This factory is not active.");
        require(msg.sender == mainTokenAdr, "TokenFactory: Only the mainTokenAdr can call this function.");

        uint forTokenBalance = IERC20(forTokenAdr_).balanceOf(address(this));        

        IERC20(mainTokenAdr).approve(uniswapRouterAdr, mainTokenAmount_);
        IERC20(forTokenAdr_).approve(uniswapRouterAdr, forTokenBalance);

        IUniswapV2Router02(uniswapRouterAdr).addLiquidity(
            mainTokenAdr,
            forTokenAdr_,
            mainTokenAmount_,
            forTokenBalance,
            0,
            0,
            address(0),
            block.timestamp
        );
    }

    /**
     * @dev Triggers the first buy for a new token, swapping a specified amount of main tokens
     * for the new token using Uniswap.
     * 
     * @param newTokenAdr_ The address of the new token to buy.
     * @param firstBuyAmount_ The amount of main tokens to use for the first buy.
     * @param to_ The address to receive the new tokens from the first buy.
     * 
     * NOTE: This function is restricted to be called only by the main token address, ensuring
     * that the first buy is controlled and coordinated.
     * 
     * WARNING: Ensure the `to_` address has approved the transfer of `firstBuyAmount_` main tokens
     * before calling this function to prevent transaction failure.
     */
    function triggerFirstBuy(address newTokenAdr_, uint firstBuyAmount_, address to_) external {
        require(msg.sender == mainTokenAdr, "TokenFactory: Only the mainTokenAdr can call this function.");

        //transfer, calculate fees/send and approve
        IERC20(mainTokenAdr).transferFrom(to_, address(this), firstBuyAmount_);

        (, uint amountAfterFee) = _calculateAndSendFees(firstBuyAmount_);

        IERC20(mainTokenAdr).approve(uniswapRouterAdr, amountAfterFee);
        //create path
        address[] memory path = new address[](2);
        path[0] = mainTokenAdr;
        path[1] = newTokenAdr_;

        //swap
        IUniswapV2Router02(uniswapRouterAdr).swapExactTokensForTokensSupportingFeeOnTransferTokens(
            amountAfterFee,
            0,
            path,
            to_,
            block.timestamp
        );
    }
}