// SPDX-License-Identifier: MIT
// OpenZeppelin Contracts (last updated v5.0.0) (token/ERC20/ERC20.sol)

pragma solidity ^0.8.20;

import '@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol';

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {OwnableHandshake} from "./utils/OwnableHandshake.sol";
import {IUniswapV2Factory} from "./interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "./interfaces/IUniswapV2Router02.sol";
import {IMainToken} from "./interfaces/IMainToken.sol";
import "./interfaces/IWETH9.sol";

interface IExecutionContract {
    function execute(uint amountOutMin0, uint amountOutMin1) external;
}
interface IStaker {
    function stake(uint amount) external;
    function stakedTokenAddress() external returns(address);
}

interface IRevenueStakers {
    function fundByFeeCollector(uint amount) external;
}


contract LiqudityAdding is OwnableHandshake {

    address public constant DEAD_ADDRESS = 0x000000000000000000000000000000000000dEaD;

    uint constant SPLIT_DEONOMINATOR = 100;
    uint public splitNominator0 = 50;
    uint public splitNominator1 = 20;
    uint public splitNominator2 = 10;
    uint public splitNominator3 = 20;

    address public revenueStaker0;
    address public revenueStaker1;
    address public revenueStaker2;
    address public revenueStaker3;

    IStaker public iStaker;

    address public mainTokenAdr;
    address public stakedTokenAdr;

    address public startPool;
    address public exchangePool;

    // ETH
    address public UNISWAP_ROUTER;
    address public UNISWAP_FACTORY;
    address public WETH;

    event ChangedFeeCollectorState(address collector, bool state);
    event SplitNominatorsChanged(uint newSplitNominator0 , uint newSplitNominator1, uint newSplitNominator2, uint newSplitNominator3);
    event RevenueStakerChanged(address newRevenueStaker0 , address newRevenueStaker1, address newRevenueStaker2, address newRevenueStaker3);
    
    constructor(address initialOwner_) OwnableHandshake(initialOwner_) {}

    function changeSplitNominators(uint split0_, uint split1_, uint split2_, uint split3_) external onlyOwner {
        require(split0_ + split1_ + split2_ + split3_ == SPLIT_DEONOMINATOR, "LiqudityAdding: The split nominator sum needs to be 100.");
        require(split3_ < SPLIT_DEONOMINATOR, "LiqudityAdding: 'split3_' needs to be smaller than 100.");
        splitNominator0 = split0_;
        splitNominator1 = split1_;
        splitNominator2 = split2_;
        splitNominator3 = split3_;
        emit SplitNominatorsChanged(split0_, split1_, split2_, split3_);
    }

    function setRevenueStaker(address revenueStaker0_, address revenueStaker1_, address revenueStaker2_, address revenueStaker3_) external onlyOwner {
        require(
            revenueStaker0_ != revenueStaker1_ &&
            revenueStaker1_ != revenueStaker2_ &&
            revenueStaker2_ != revenueStaker3_, 
            "LiquidityAdding: The revenue staker need to be different."
        );
        revenueStaker0 = revenueStaker0_;
        revenueStaker1 = revenueStaker1_;
        revenueStaker2 = revenueStaker2_;
        revenueStaker3 = revenueStaker3_;
        emit RevenueStakerChanged(revenueStaker0_, revenueStaker1_, revenueStaker2_, revenueStaker3_);
    }

    function setExchangePool(address exchangePool_) external onlyOwner {
        exchangePool = exchangePool_;
    }

    function _setStaker(address stakerAdr_) internal {
        require(stakedTokenAdr == address(0), "LiqudityAdding: Already set.");
        iStaker = IStaker(stakerAdr_);
        stakedTokenAdr = iStaker.stakedTokenAddress();
        IERC20(stakedTokenAdr).approve(address(UNISWAP_ROUTER), type(uint256).max);
    }

    function setTokenAndStaker(address mainTokenAdr_, address stakerAdr_) external onlyOwner {
        require(mainTokenAdr == address(0), "LiqudityAdding: 'mainTokenAdr' already set.");
        mainTokenAdr = mainTokenAdr_;
        
        UNISWAP_FACTORY = IMainToken(mainTokenAdr).UNISWAP_FACTORY();
        UNISWAP_ROUTER = IMainToken(mainTokenAdr).UNISWAP_ROUTER();
        WETH = IMainToken(mainTokenAdr).WETH();

        _setStaker(stakerAdr_);

        IERC20(mainTokenAdr).approve(address(iStaker), type(uint256).max);
        IERC20(mainTokenAdr).approve(address(UNISWAP_ROUTER), type(uint256).max);
    }

    function _startLiq() internal {
        uint amount0 = address(this).balance;
        uint amount1 = IERC20(mainTokenAdr).balanceOf(address(this));

        IERC20(mainTokenAdr).approve(address(UNISWAP_ROUTER), amount1);

        IUniswapV2Router02(UNISWAP_ROUTER).addLiquidityETH{value:amount0}(
            mainTokenAdr,
            amount1,
            0,
            0,
            address(this),
            block.timestamp
        );


        address uniswapV2Pool = IUniswapV2Factory(UNISWAP_FACTORY).getPair(mainTokenAdr, WETH);

        startPool = uniswapV2Pool;

        IMainToken(mainTokenAdr).setStartUnlimitedAccounts(uniswapV2Pool);

        IERC20(uniswapV2Pool).transfer(DEAD_ADDRESS, IERC20(uniswapV2Pool).balanceOf(address(this)));

    }

    function createStartLiq() external onlyOwner {
        require(startPool == address(0), "LiquidityAdding: Already created.");
        _startLiq();
    }

    function isFeeCollector(address toCheck_) public view returns(bool) {
        return toCheck_ == revenueStaker0 || toCheck_ == revenueStaker1 || toCheck_ == revenueStaker2;
    }

    function autoCollect() external {
        require(isFeeCollector(msg.sender), "LiquidityManager: only a 'revenueStaker' can execute this function.");

        uint amountMainToken = IERC20(mainTokenAdr).balanceOf(address(this));

        uint toSend3 = amountMainToken * splitNominator3 / SPLIT_DEONOMINATOR;

        feeRoute(amountMainToken - toSend3);

        uint amountStakedToken = IERC20(stakedTokenAdr).balanceOf(address(this));

        uint denominator = SPLIT_DEONOMINATOR - splitNominator3;

        uint toSend0 = amountStakedToken * splitNominator0 / denominator;
        uint toSend1 = amountStakedToken * splitNominator1 / denominator;
        uint toSend2 = amountStakedToken * splitNominator2 / denominator;

        uint amountETH = address(this).balance;

        uint toSendETH0 = amountETH * splitNominator0 / SPLIT_DEONOMINATOR;
        uint toSendETH1 = amountETH * splitNominator1 / SPLIT_DEONOMINATOR;
        uint toSendETH2 = amountETH * splitNominator2 / SPLIT_DEONOMINATOR;


        if (toSend0 > 0) {
            IERC20(stakedTokenAdr).transfer(revenueStaker0, toSend0);
            IRevenueStakers(revenueStaker0).fundByFeeCollector(toSend0);
        }
        if (toSend1 > 0) {
            IERC20(stakedTokenAdr).transfer(revenueStaker1, toSend1);
            IRevenueStakers(revenueStaker1).fundByFeeCollector(toSend1);
        }
        if (toSend2 > 0) {
            IERC20(stakedTokenAdr).transfer(revenueStaker2, toSend2);
            IRevenueStakers(revenueStaker2).fundByFeeCollector(toSend2);
        }
        if (toSend3 > 0) {
            IERC20(mainTokenAdr).transfer(revenueStaker3, toSend3);
        }

        if (toSendETH0 > 0) {
            payable(revenueStaker0).transfer(toSendETH0);
        }
        if (toSendETH1 > 0) {
            payable(revenueStaker1).transfer(toSendETH1);
        }
        if (toSendETH2 > 0) {
            payable(revenueStaker2).transfer(toSendETH2);
        }

        payable(revenueStaker3).transfer(amountETH - toSendETH0 - toSendETH1 - toSendETH2);
    }

    function getAutoCollectAmount(address forAdr) external view returns(uint) {
        uint returnValue = 0;
        uint amountMainToken = IERC20(mainTokenAdr).balanceOf(address(this));
        uint return3 = amountMainToken * splitNominator3 / SPLIT_DEONOMINATOR;

        uint amountStakedToken = IERC20(stakedTokenAdr).balanceOf(address(this)) + amountMainToken - return3;
        uint denominator = SPLIT_DEONOMINATOR - splitNominator3;

        if (forAdr == revenueStaker0) {
            returnValue = amountStakedToken * splitNominator0 / denominator;
        }
        if (forAdr == revenueStaker1) {
            returnValue = amountStakedToken * splitNominator1 / denominator;
        }
        if (forAdr == revenueStaker2) {
            returnValue = amountStakedToken * splitNominator2 / denominator;
        }
        if (forAdr == revenueStaker3) {
            returnValue = return3;
        }
        return returnValue;
    }

    function feeRoute(uint amountERC_) private {
        if (exchangePool != address(0)) {

            address[] memory path0 = new address[](2);
            path0[0] = mainTokenAdr;
            path0[1] = stakedTokenAdr;

            address[] memory path1 = new address[](2);
            path1[0] = stakedTokenAdr;
            path1[1] = mainTokenAdr;

            uint[] memory temp1 = IUniswapV2Router02(UNISWAP_ROUTER).getAmountsOut(amountERC_, path0);
            uint[] memory temp2 = IUniswapV2Router02(UNISWAP_ROUTER).getAmountsOut(amountERC_, path1);

            uint outSwap = temp1[temp1.length - 1];
            uint outMintSwapMint = temp2[temp1.length - 1];

            if (outSwap > amountERC_) {
                IUniswapV2Router02(UNISWAP_ROUTER).swapExactTokensForTokens(amountERC_, outSwap, path0, address(this), block.timestamp);
            } else {
                if (outMintSwapMint > amountERC_) {
                    iStaker.stake(amountERC_);
                    IUniswapV2Router02(UNISWAP_ROUTER).swapExactTokensForTokens(amountERC_, outMintSwapMint, path1, address(this), block.timestamp);
                    iStaker.stake(outMintSwapMint);
                } else {
                    iStaker.stake(amountERC_);
                }
            }
        } else {
            iStaker.stake(amountERC_);
        }
    }


    function withdrawERC20(address to_, address token_, uint amount_) external onlyOwner {
        if (token_ == WETH) {
            uint wethBalance = IWETH9(WETH).balanceOf(address(this));
            uint ethBalance = address(this).balance;

            require(wethBalance + ethBalance >= amount_, "LiqudityAdding: Not enough ETH.");

            if (ethBalance < amount_) {
                uint diff = amount_ - ethBalance;
                IWETH9(WETH).withdraw(diff);
            }

            payable(to_).transfer(amount_);

        } else {
            IERC20(token_).transfer(to_, amount_);
        }
    }

    function claimETH() external onlyOwner {
        payable(owner()).transfer(address(this).balance);
    }

    function claimERC20(address token_) external onlyOwner {
        IERC20(token_).transfer(owner(), IERC20(token_).balanceOf(address(this)));
    }

    function test() external payable {}

    receive() external payable {}
}