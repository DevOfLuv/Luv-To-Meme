// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";


import {IWETH9} from "../interfaces/IWETH9.sol";
import {IUniswapV2Factory} from "../interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "../interfaces/IUniswapV2Router02.sol";
import {OwnableHandshake} from "../utils/OwnableHandshake.sol";



contract VolumeAsk is ReentrancyGuard, OwnableHandshake {
    using SafeERC20 for IERC20;

    bool public openForAll = true;

    address public feeAccount;
    // ETH: 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2
    // BASE: 0x4200000000000000000000000000000000000006
    // TBNB: 0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd
    address public constant WETH = 0xD99D1c33F9fC3444f8101754aBC46c52416550D1;
    IWETH9 public immutable weth = IWETH9(WETH);

    // ETH: 0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45
    // BASE: 0x2626664c2603336E57B271c5C0b26F421741e481
    // TBNB: 0xD99D1c33F9fC3444f8101754aBC46c52416550D1
    IUniswapV2Router02 public immutable uniswapV2Router = IUniswapV2Router02(0xD99D1c33F9fC3444f8101754aBC46c52416550D1);



    uint constant GAS_DONOMINATOR = 10000;

    struct AskStruct {
        address creator;
        uint id;
        address token0;
        address token1;
        uint tradeSize;
        uint tokenReserve;
        uint ethReserve;
        uint gasMultiplier;
        address solver;
        uint maxCallsPerBlock;
        uint swapAmounts;
    }

    mapping(address => mapping(address => uint)) public asksIds;
    mapping(uint => mapping(uint => uint)) public happendBundleSwapsPerBlockById;

    AskStruct[] public asks;

    event CreateAsk(
        address creator,
        uint id,
        address token0,
        address token1,
        uint tradeSize,
        uint tokenReserve,
        uint ethReserve,
        uint gasMultiplier,
        address solver,
        uint maxCallsPerBlock,
        uint swapAmounts
    );

    event AddedSolver(uint indexed id, address indexed solver);
    event RemovedSolver(uint indexed id, address indexed solver);
    event NewAsk(uint indexed newId, address creator, address token1);
    event FundedAsk(uint indexed id, address indexed funder, uint amountToken0, uint amountETH);
    event FeeAccountChanged(address indexed oldFeeAccount, address indexed newFeeAccount);
    event OpenForAll(bool openForAll);

    modifier isOpenForAll() {
        require(openForAll || msg.sender == owner(), "VolumeAsk: Not open for all");
        _;
    }

    constructor() OwnableHandshake(msg.sender){
        asks.push(
            AskStruct(
                address(0),
                0,
                address(0),
                address(0),
                0,
                0,
                0,
                0,
                address(0),
                0,
                0
            )
        );
    } 

    /**
     * @dev Sets the fee account.
     * @param feeAccount_ The address of the new fee account.
     */
    function setFeeAccount(address feeAccount_) external onlyOwner {
        emit FeeAccountChanged(feeAccount, feeAccount_);
        feeAccount = feeAccount_;
    }

    /**
     * @dev Creates a swap.
     * @param ask_ The parameters for the swap.
     */
    function _createSwap(AskStruct memory ask_) internal {
        require(
            asksIds[ask_.creator][ask_.token1] == 0,
            "Swap already exists"
        );
        asksIds[ask_.creator][ask_.token1] = asks.length;
        asks.push(ask_);
        emit CreateAsk(
            ask_.creator,
            asks.length,
            ask_.token0,
            ask_.token1,
            ask_.tradeSize,
            ask_.tokenReserve,
            ask_.ethReserve,
            ask_.gasMultiplier,
            ask_.solver,
            ask_.maxCallsPerBlock,
            ask_.swapAmounts
        );
    }

    /**
     * @dev Creates a swap.
     * @param ask_ The parameters for the swap.
     */
    function createSwap(
        AskStruct memory ask_
    ) external payable nonReentrant isOpenForAll {
        require(ask_.token0 != address(0), "Invalid token0");
        require(ask_.token1 != address(0), "Invalid token1");
        require(ask_.tradeSize > 0, "Invalid trade size");
        require(
            ask_.tokenReserve > 0 && ask_.ethReserve > 0,
            "Invalid reserves"
        );

        require(ask_.gasMultiplier > 0, "Invalid gas multiplier");
        _createSwap(ask_);

        uint fee = ask_.tokenReserve * 1 / 100;

        if (ask_.token0 != WETH) {
            require(msg.value == ask_.ethReserve, "Incorrect ETH sent");
            IERC20(ask_.token0).safeTransferFrom(
                msg.sender,
                address(this),
                ask_.tokenReserve
            );
            if (feeAccount != address(0)) {
                IERC20(ask_.token0).safeTransferFrom(msg.sender,feeAccount, fee);
            }
        } else {
            require(
                msg.value == ask_.ethReserve + ask_.tokenReserve + fee,
                "Incorrect ETH sent (should be sum of 'ethReserve' and 'tokenReserve')"
            );
            weth.deposit{value: ask_.tokenReserve}();
            (bool success, ) = payable(feeAccount).call{value: fee}("");
            require(success, "Failed to send ETH fee");
        }
        IERC20(ask_.token0).approve(address(uniswapV2Router), ~uint256(0));
        IERC20(ask_.token1).approve(address(uniswapV2Router), ~uint256(0));
    }

    /**
     * @dev Funds a swap.
     * @param id_ The ID of the swap.
     * @param amountToken0 The amount of token0 to fund.
     */
    function fundSwap(uint id_, uint amountToken0) external payable nonReentrant isOpenForAll {
        require(amountToken0 > 0 || msg.value > 0, "Amount must be greater than 0");

        uint amountETH;

        uint fee = amountToken0 * 1 / 100;

        if (asks[id_].token0 != WETH) {
            IERC20(asks[id_].token0).safeTransferFrom(
                msg.sender, address(this), amountToken0
            );
            asks[id_].tokenReserve += amountToken0;
            if (feeAccount != address(0)) {
                IERC20(asks[id_].token0).safeTransferFrom(msg.sender,feeAccount, fee);
            }
        } else {
            require(msg.value >= amountToken0 + fee, "Incorrect ETH sent");
            asks[id_].tokenReserve += amountToken0;
            weth.deposit{value: amountToken0}();
            amountETH = msg.value - amountToken0 - fee;
            asks[id_].ethReserve += amountETH;
            (bool success, ) = payable(feeAccount).call{value: fee}("");
            require(success, "Failed to send ETH fee");
        }

        emit FundedAsk(id_, msg.sender, amountToken0, amountETH);
    }

    /**
     * @dev Updates a swap.
     * @param id_ The ID of the swap.
     * @param ask_ The parameters for the swap.
     */
    function updateAsk(uint id_, AskStruct memory ask_) external nonReentrant{
        require(msg.sender == asks[id_].creator, "Only the creator can update the ask");
        require(ask_.token0 == asks[id_].token0 || ask_.token1 == asks[id_].token1, "Invalid entry to change this values create a new ask");
        require(ask_.ethReserve == 0 || ask_.tokenReserve == 0, "Invalid entry to change this values fund your existing ask");
        asks[id_] = ask_;
    }

    /**
     * @dev Makes swaps for a given swap.
     * @param id_ The ID of the swap.
     */
    function _makeSwaps(uint id_) internal {
        address[] memory path0 = new address[](2);
        path0[0] = asks[id_].token0;
        path0[1] = asks[id_].token1;

        address[] memory path1 = new address[](2);
        path1[0] = asks[id_].token1;
        path1[1] = asks[id_].token0;

        uint bal1Start = IERC20(asks[id_].token1).balanceOf(
            address(this)
        );

        uint diff;

        for (uint i = 0; i < asks[id_].swapAmounts; i++) {
            uniswapV2Router
                .swapExactTokensForTokensSupportingFeeOnTransferTokens(
                    asks[id_].tradeSize,
                    0,
                    path0,
                    address(this),
                    block.timestamp
                );
            diff =
                IERC20(asks[id_].token1).balanceOf(address(this)) -
                bal1Start;

            uniswapV2Router
                .swapExactTokensForTokensSupportingFeeOnTransferTokens(
                    diff,
                    0,
                    path1,
                    address(this),
                    block.timestamp
                );
        }
    }

    /**
     * @dev Makes swaps for a given swap.
     * @param id_ The ID of the swap.
     */
    function makeSwaps(uint id_) external nonReentrant isOpenForAll {
        uint gasStart = gasleft();
        require(
            msg.sender == asks[id_].solver ||
                address(0) == asks[id_].solver,
            "Only the solver can make swaps"
        );
        require(asks[id_].maxCallsPerBlock > happendBundleSwapsPerBlockById[id_][block.number], "No more swaps allowed for this block and this ask");

        uint swapFee = asks[id_].tradeSize * asks[id_].swapAmounts * 6 / 1000;
        require(asks[id_].tradeSize + swapFee <= asks[id_].tokenReserve, "'tokenReserve' to less for the amount of swaps that will be made");

        uint balToken0Start = IERC20(asks[id_].token0).balanceOf(
            address(this)
        );

        _makeSwaps(id_);

        uint balToken0End = IERC20(asks[id_].token0).balanceOf(
            address(this)
        );

        uint usedFunds = balToken0Start - balToken0End;

        asks[id_].tokenReserve -= usedFunds;

        happendBundleSwapsPerBlockById[id_][block.number]++;

        uint gasUsed = gasStart - gasleft();
        uint toSendGas = (gasUsed * asks[id_].gasMultiplier) /
            GAS_DONOMINATOR;
        //will fail if not enough ETH reserved
        require(
            toSendGas <= asks[id_].ethReserve,
            "Not enough ETH reserved"
        );
        (bool success, ) = payable(msg.sender).call{value: toSendGas}("");
        require(success, "Failed to send ETH");
    }
}