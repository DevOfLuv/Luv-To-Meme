// SPDX-License-Identifier: MIT

pragma solidity ^0.8.20;

// interface for checking the last transaction of the main token contract
interface IMainTokenChecker {
    function lastTransaction(address account) external view returns (uint);
}

abstract contract BotProtector {

    //interface for checking the last transaction of the main token contract
    IMainTokenChecker public iMainTokenChecker;

    //saves the block number of the last transaction of an address
    mapping (address => uint) public lastTransaction;


    /**
     * @dev Modifier for transfers. Checks if 'from_' or 'to_' had already a transaction via 'lastTransaction' at this block. Also set the current 'block.number' at not whitelisted
     *      addresses. If a address is whitelisted to make more than one transaction per block the 'lastTransaction' is set to '1'.
     *      
     * 
     * @param from_ sender of a transaction.
     * @param to_ receiver of a transaction.
     *
     * NOTE Liquidity pools have to be whitelisted.
     *      Both 'from_' and 'to_' will get blocked for this block if not marked for unlimted transactions.
     *      If one of the two is marked for unlimited transactions, the other one will get blocked for this block.
     *      The Botprotection is kind of centralized, because it checks the last transaction of the address via the 'iMainTokenChecker' contract.
     */
    modifier protectAgainsBots(address from_, address to_) virtual {
        _checkTransaction(from_, to_);
        _;
    }
    event UnlimitedAccountChange(address account, bool unlimited);

    /**
     * @dev Constructor.
     */
    constructor(address iMainTokenChecker_) {
        iMainTokenChecker =  IMainTokenChecker(iMainTokenChecker_);
    }

    /**
     * @dev Modifier for transfers. Checks if 'from_' or 'to_' had already a transaction via 'lastTransaction' at this block. Also set the current 'block.number' at not whitelisted
     *      addresses. If a address is whitelisted to make more than one transaction per block the 'lastTransaction' is set to '1'.
     *      
     * 
     * @param from_ sender of a transaction.
     * @param to_ receiver of a transaction.
     *
     * NOTE Liquidity pools have to be whitelisted.
     *      Both 'to_' and 'from' will get blocked for this block if not marked for unlimted transactions.
     *      If one of the two is marked for unlimited transactions, the other one will get blocked for this block.
     *      The Botprotection is kind of centralized, because it checks the last transaction of the address via the 'iMainTokenChecker' contract.
     */
    function _checkTransaction(address from_, address to_) internal {
        uint blockNr = block.number;

        _updateLastTransaction(from_, blockNr);
        _updateLastTransaction(to_, blockNr);
    }

    /**
     * @dev Update the last transaction block of a given address.
     * 
     * @param account_ address to check.
     * @param blockNr_ block number to check.
     * 
     * NOTE: If the address is not whitelisted to make more than one transaction per block, the last transaction block is updated to the current block number.
     *       If the address is whitelisted to make more than one transaction per block, the last transaction block is updated to '1'.
     */
    function _updateLastTransaction(address account_, uint blockNr_) internal {
        if (iMainTokenChecker.lastTransaction(account_) != 1) {
            if (lastTransaction[account_] < blockNr_) {
                lastTransaction[account_] = blockNr_;
            } else {
                revert("BotProtector: Only one transaction per block.");
            }
        }
    }

    /**
     * @dev Change the last transaction block of a given address to '1'.
     * 
     * @param account_ address to set.
     * @param unlimited_ state. true = 1, false = current block number
     * 
     * NOTE: Addresses will get checked if they set to 1 in '_checkTransaction', which take away the restriction of one transaction per block.
     * 
     */
    function _changeUnlimitedAccount(address account_, bool unlimited_) internal {
        lastTransaction[account_] = unlimited_ ? 1 : block.number;
        emit UnlimitedAccountChange(account_, unlimited_);
    }

    /**
     * @dev Change the last transaction block of a given address to '1'.
     * 
     * @param toCheck_ address to check.
     * 
     * @return bool true=unlimited transactions per block, false=one transaction per block
     * 
     * NOTE: just for easy checking with bool returns
     */
    function unlimitedTransactionAccount(address toCheck_) external view returns(bool) {
        if (lastTransaction[toCheck_] == 1) {
            return true;
        } else {
            return false;
        }
    }

}