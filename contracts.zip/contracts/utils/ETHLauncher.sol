// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import {IUniswapV2Factory} from "../interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "../interfaces/IUniswapV2Router02.sol";


import {IMEMEMetadata} from "../interfaces/IMEMEMetadata.sol";
import {ITokenFactory01} from "../interfaces/ITokenFactory01.sol";
import {ITokenFactory02} from "../interfaces/ITokenFactory02.sol";
import {ITokenFactory03} from "../interfaces/ITokenFactory03.sol";
import {ISideToken_CLOG} from "../interfaces/ISideToken_CLOG.sol";
import {IMainToken} from "../interfaces/IMainToken.sol";

import {MEMEMetadata} from "../utils/MEMEMetadata.sol";
import {SideToken_CLOG} from "../SideToken_CLOG.sol";

import {OwnableHandshake} from "./OwnableHandshake.sol";

contract ETHLauncher is OwnableHandshake, ReentrancyGuard {

    address public weth;
    address public factoryERC;
    address public factoryERCRouter;
    address public factoryFEE;
    address public factoryFEErouter;
    address public factoryCLOG;
    address public factoryCLOGrouter;
    address public mainTokenAdr;

    address public baseRouter;


    constructor(address mainTokenAdr_, address factoryERC_, address factoryFEE_, address factoryCLOG_) OwnableHandshake(msg.sender) {
        factoryERC = factoryERC_;
        factoryERCRouter = ITokenFactory01(factoryERC_).uniswapRouterAdr();
        factoryFEE = factoryFEE_;
        factoryFEErouter = ITokenFactory02(factoryFEE_).uniswapRouterAdr();
        factoryCLOG = factoryCLOG_;
        factoryCLOGrouter = ITokenFactory03(factoryCLOG_).uniswapRouterAdr();

        mainTokenAdr = mainTokenAdr_;
        baseRouter = IMainToken(mainTokenAdr).UNISWAP_ROUTER();
        weth = IMainToken(mainTokenAdr).WETH();
    }

    function _swapETHtoMainToken(uint amountIn) internal  returns(uint amountOut){
        address here = address(this);

        address[] memory path = new address[](2);
        path[0] = weth;
        path[1] = mainTokenAdr;

        uint balanceBefore = IERC20(mainTokenAdr).balanceOf(here);

        IUniswapV2Router02(baseRouter).swapExactETHForTokensSupportingFeeOnTransferTokens{value: amountIn}
        (
            0,
            path,
            here,
            block.timestamp
        );
        return IERC20(mainTokenAdr).balanceOf(here) - balanceBefore;
    }

    function createERC20Token(
        string memory name_, string memory symbol_, uint8 decimals_, uint totalSupply_, address mediaAccount_, uint mainTokenAmount_, uint salt_, uint firstBuyAmount_,
        MEMEMetadata.Metadata memory metadata_, uint minLuvAmountOut_
    ) external payable nonReentrant {
        require(msg.value == firstBuyAmount_, "ETHLauncher: Incorrect ETH amount");

        uint firstBuyAmountAfterSwap = _swapETHtoMainToken(firstBuyAmount_);

        require(firstBuyAmountAfterSwap >= minLuvAmountOut_, "ETHLauncher: Insufficient amount after swap");

        IERC20(mainTokenAdr).approve(factoryERC, firstBuyAmountAfterSwap);

        ITokenFactory01(factoryERC).createERC20Token(name_, symbol_, decimals_, totalSupply_, mediaAccount_, mainTokenAmount_, salt_, firstBuyAmountAfterSwap, metadata_);

        address token = ITokenFactory01(factoryERC).createdToken(ITokenFactory01(factoryERC).createdTokenLength() - 1);

        IERC20(token).transfer(msg.sender, IERC20(token).balanceOf(address(this)));
    }

    function createFEEToken(
        string memory name_, string memory symbol_, uint8 decimals_, uint totalSupply_, address mediaAccount_, uint mainTokenAmount_, address feeAccount_, uint16 feeNominator_, uint salt_, uint firstBuyAmount_,
        MEMEMetadata.Metadata memory metadata_, uint minLuvAmountOut_
    ) external payable nonReentrant {
        require(msg.value == firstBuyAmount_, "ETHLauncher: Incorrect ETH amount");

        uint firstBuyAmountAfterSwap = _swapETHtoMainToken(firstBuyAmount_);

        require(firstBuyAmountAfterSwap >= minLuvAmountOut_, "ETHLauncher: Insufficient amount after swap");

        IERC20(mainTokenAdr).approve(factoryFEE, firstBuyAmountAfterSwap);

        ITokenFactory02(factoryFEE).createFEEToken(name_, symbol_, decimals_, totalSupply_, mediaAccount_, mainTokenAmount_, feeAccount_, feeNominator_, salt_, firstBuyAmountAfterSwap, metadata_);

        address token = ITokenFactory02(factoryFEE).createdToken(ITokenFactory02(factoryFEE).createdTokenLength() - 1);

        IERC20(token).transfer(msg.sender, IERC20(token).balanceOf(address(this)));
    }

    function createCLOGToken(
        string memory name_, string memory symbol_, uint8 decimals_, uint totalSupply_, address mediaAccount_, uint mainTokenAmount_, address feeAccount_, uint salt_, uint firstBuyAmount_,
        SideToken_CLOG.ClogParams memory contractStruct_,  MEMEMetadata.Metadata memory metadata_, uint minLuvAmountOut_
    ) external payable nonReentrant {
        require(msg.value == firstBuyAmount_, "ETHLauncher: Incorrect ETH amount");

        uint firstBuyAmountAfterSwap = _swapETHtoMainToken(firstBuyAmount_);

        require(firstBuyAmountAfterSwap >= minLuvAmountOut_, "ETHLauncher: Insufficient amount after swap");

        IERC20(mainTokenAdr).approve(factoryCLOG, firstBuyAmountAfterSwap);

        ITokenFactory03(factoryCLOG).createCLOGToken(name_, symbol_, decimals_, totalSupply_, mediaAccount_, mainTokenAmount_, feeAccount_, salt_, firstBuyAmountAfterSwap, contractStruct_, metadata_);

        address token = ITokenFactory03(factoryCLOG).createdToken(ITokenFactory03(factoryCLOG).createdTokenLength() - 1);

        IERC20(token).transfer(msg.sender, IERC20(token).balanceOf(address(this)));
    }

    receive() external payable {}
}

