// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;


abstract contract MEMEMetadata {

    address public mediaAccount;
    address public factory;

    struct Metadata {
        string uri;
        string description;
        string logo;
        string website;
        string telegram;
        string twitter;
        string discord;
    }

    Metadata private _metadata;

    /**
     * @dev Modifier to check if the caller is the media account.
     * 
     */
    modifier onlyMediaAccount() {
        require(msg.sender == mediaAccount, "MEMEMetadata: Only the 'mediaAccount' can call this function.");
        _;
    }

    /**
     * @dev Modifier to check if the caller is the media account or the 'factory' address. 
     * 
     * NOTE In this context the 'factory' is the deployer of the 'SideToken' and the DAO can change the media account (not the media links) per vote.
     * 
     */
    modifier onlyMediaAccountOrFactory() {
        require(msg.sender == mediaAccount || msg.sender == factory, "MEMEMetadata: Only the 'mediaAccount' or the 'factory' can call this function.");
        _;
    }

    event MediaAccountChanged(address newMediaAccount);
    event UriChanged(string newLink);
    event DescriptionChanged(string newDescription);
    event LogoChanged(string newLink);
    event WebsiteChanged(string newLink);
    event TelegramChanged(string newLink);
    event TwitterChanged(string newLink);
    event DiscordChanged(string newLink);

    /**
     * @dev Constructor sets all given links via 'changeAllMedia'
     * 
     * @param mediaAccount_ address which is allowed to change the metadata.
     * @param metadata_ metadata to set.
     */
    constructor(address mediaAccount_, Metadata memory metadata_) {
        mediaAccount = mediaAccount_;
        factory = msg.sender;
        _changeAllMedia(metadata_);
        emit MediaAccountChanged(mediaAccount_);
    }

    /**
     * @dev Get the 'uri' string.
     * 
     * @return uri_ the 'uri' string.
     */
    function uri() public view returns (string memory) {
        return _metadata.uri;
    }

    /**
     * @dev Get the 'description' string.
     * 
     * @return description_ the 'description' string.
     */
    function description() public view returns (string memory){
        return _metadata.description;
    }

    /**
     * @dev Get the 'logo' string.
     * 
     * @return logo_ the 'logo' string.
     */
    function logo() public view returns (string memory) {
        return _metadata.logo;
    }

    /**
     * @dev Get the 'website' string.
     * 
     * @return website_ the 'website' string.
     */
    function website() public view returns (string memory) {
        return _metadata.website;
    }
    
    /**
     * @dev Get the 'telegram' string.
     * 
     * @return telegram_ the 'telegram' string.
     */
    function telegram() public view returns (string memory) {
        return _metadata.telegram;
    }

    /**
     * @dev Get the 'twitter' string.
     * 
     * @return twitter_ the 'twitter' string.
     */
    function twitter() public view returns (string memory) {
        return _metadata.twitter;
    }

    /**
     * @dev Get the 'discord' string.
     * 
     * @return discord_ the 'discord' string.
     */
    function discord() public view returns (string memory) {
        return _metadata.discord;
    }

    /**
     * @dev Change the current media account.
     *      
     * @param newMediaAccount_ the to set media account.
     *
     * NOTE Can only be called by the current media account or indirect via 'factory' from the DAO in this context.
     */
    function changeMediaAccount(address newMediaAccount_) external onlyMediaAccountOrFactory {
        mediaAccount = newMediaAccount_;
        emit MediaAccountChanged(newMediaAccount_);
    }

    /**
     * @dev Change the 'uri' string.
     *      
     * @param newUri_ new uri.
     *
     * NOTE Can only be called by the current media account.
     */
    function changeUri(string calldata newUri_) external onlyMediaAccount {
        _metadata.uri = newUri_;
        emit UriChanged(newUri_);

    }

    /**
     * @dev Change the 'description' string.
     *      
     * @param newDescription_ new description.
     *
     * NOTE Can only be called by the current media account.
     */
    function changeDescription(string calldata newDescription_) external onlyMediaAccount {
        _metadata.description = newDescription_;
        emit DescriptionChanged(newDescription_);
    }

    /**
     * @dev Change the 'logo' string.
     *      
     * @param newLogo_ new telegram.
     *
     * NOTE Can only be called by the current media account.
     */
    function changeLogo(string calldata newLogo_) external onlyMediaAccount {
        _metadata.logo = newLogo_;
        emit LogoChanged(newLogo_);
    }

    /**
     * @dev Change the 'website' string.
     *      
     * @param newWebsite_ new telegram.
     *
     * NOTE Can only be called by the current media account.
     */
    function changeWebsite(string calldata newWebsite_) external onlyMediaAccount {
        _metadata.website = newWebsite_;
        emit WebsiteChanged(newWebsite_);
    }

    /**
     * @dev Change the 'telegram' string.
     *      
     * @param newTelegram_ new telegram.
     *
     * NOTE Can only be called by the current media account.
     */
    function changeTelegram(string calldata newTelegram_) external onlyMediaAccount {
        _metadata.telegram = newTelegram_;
        emit TelegramChanged(newTelegram_);
    }

    /**
     * @dev Change the 'twitter' string.
     *      
     * @param newTwitter_ new twitter.
     *
     * NOTE Can only be called by the current media account.
     */
    function changeTwitter(string calldata newTwitter_) external onlyMediaAccount {
        _metadata.twitter = newTwitter_;
        emit TwitterChanged(newTwitter_);
    }

    /**
     * @dev Change the 'discord' string.
     *      
     * @param newDiscord_ new discord.
     *
     * NOTE Can only be called by the current media account.
     */
    function changeDiscord(string calldata newDiscord_) external onlyMediaAccount {
        _metadata.discord = newDiscord_;
        emit DiscordChanged(newDiscord_);
    }

    /**
     * @dev Change the all metadata.
     *      
     * @param metadata_ new metadata.
     *
     * NOTE Changing without proof. 
     *      Can only be called by the current media account.
     * 
     * WARNING: Not changed mediadata should also given.
     */
    function _changeAllMedia(Metadata memory metadata_) internal {
        _metadata.uri = metadata_.uri;
        _metadata.description = metadata_.description;
        _metadata.logo = metadata_.logo;
        _metadata.website = metadata_.website;
        _metadata.telegram = metadata_.telegram;
        _metadata.twitter = metadata_.twitter;
        _metadata.discord = metadata_.discord;

        emit UriChanged(metadata_.uri);
        emit DescriptionChanged(metadata_.description);
        emit LogoChanged(metadata_.logo);
        emit WebsiteChanged(metadata_.website);
        emit TelegramChanged(metadata_.telegram);
        emit TwitterChanged(metadata_.twitter);
        emit DiscordChanged(metadata_.discord);
    }

    /**
     * @dev Change the all metadata.
     *      
     * @param metadata_ new metadata.
     *
     * NOTE Changing without proof. 
     *      Can only be called by the current media account.
     * 
     * WARNING: Not changed mediadata should also given.
     */
    function changeAllMedia(Metadata memory metadata_) public onlyMediaAccount {
        _changeAllMedia(metadata_);
    }

    /**
     * @dev Get the metadata.
     * 
     * @return mediaAccount_ the mediaAccount.
     * @return uri_ the uri.
     * @return description_ the description.
     * @return logo_ the logo.
     * @return website_ the website.
     * @return telegram_ the telegram.
     * @return twitter_ the twitter.
     * @return discord_ the discord.
     */
    function metadata() public view returns (
        address mediaAccount_,
        string memory uri_,
        string memory description_,
        string memory logo_,
        string memory website_,
        string memory telegram_,
        string memory twitter_,
        string memory discord_
    ) {
        mediaAccount_ = mediaAccount;
        uri_ = _metadata.uri;
        description_ = _metadata.description;
        logo_ = _metadata.logo;
        website_ = _metadata.website;
        telegram_ = _metadata.telegram;
        twitter_ = _metadata.twitter;
        discord_ = _metadata.discord;
    }


}