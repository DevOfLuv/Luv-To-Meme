// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {OwnableHandshake} from "./OwnableHandshake.sol";

interface IFeeSource {
    function autoCollect() external;
    function getAutoCollectAmount(address forAdr) external view returns(uint);
}

interface IStaker {
    function stake(uint amount) external;
}

contract RevenueStaking is ReentrancyGuard, OwnableHandshake {
    using SafeERC20 for IERC20;

    uint constant public SHARE_DENOMINATOR = 10**12;

    uint public lastCalculationBlock;
    uint public claimablePerShareERC;
    uint public claimablePerShareETH;
    uint public restERC;
    uint public restETH;

    uint private totalShares;

    // 60*60*24*365.25 / 2
    uint public blocksPerYear = 15778800;

    struct Stakes {
        uint shares;
        uint claimablePerShareEntryERC;
        uint claimablePerShareEntryETH;
        uint unclaimedERC;
        uint unclaimedETH;
    }

    address public stakedTokenAdr;
    address public rewardTokenAdr;
    address public feeSourceAdr;


    mapping(address => Stakes) public stakes;

    event StakeAdded(address account, uint shares);
    event StakeRemoved(address account, uint stakedAmount);
    event RewardReleased(address to, uint amountERC);
    event FundsReceived(address from, uint amountERC);
    event blocksPerYearChanged(uint oldValue, uint newValue);
    event FeeSourceChanged(address oldValue, address newValue);
    /**
     * @dev Constructor sets the 'stakerAdr' which is used to stake the main token, the 'stakedTokenAdr'
     *      which is the token received when staking in the 'stakerAdr'-contract, the 'feeSourceAdr' is
     *      the contract where fees for the reward can be collected.
     * 
     * @param stakedTokenAdr_ address of the staked token.
     * @param feeSourceAdr_ address where fees can be collected.
     * @param initialOwner_ address of the owner.
     */
    constructor(address rewardTokenAdr_, address stakedTokenAdr_, address feeSourceAdr_, address initialOwner_) OwnableHandshake(initialOwner_){
        rewardTokenAdr = rewardTokenAdr_;
        stakedTokenAdr = stakedTokenAdr_;
        feeSourceAdr = feeSourceAdr_;
    }

    /**
     * @dev Changes the 'blocksPerYear' and emits an event with the old and new value.
     * 
     * @param blocksPerYear_ new value for 'blocksPerYear'
     */
    function changeBlocksPerYear(uint blocksPerYear_) external onlyOwner {
        _askFund();
        _fundCalc();
        emit blocksPerYearChanged(blocksPerYear, blocksPerYear_);
        blocksPerYear = blocksPerYear_;
    }

    /**
     * @dev Changes the 'feeSourceAdr' and emits an event with the old and new value.
     * 
     * @param feeSourceAdr_ new value for 'feeSourceAdr'
     */
    function changeFeeSource(address feeSourceAdr_) external onlyOwner {
        _askFund();
        _fundCalc();
        emit FeeSourceChanged(feeSourceAdr, feeSourceAdr_);
        feeSourceAdr = feeSourceAdr_;
    }

    /**
     * @dev Collecting generated fees and increase the rewards for stakers by calling '_askFund'
     * 
     * NOTE Goes through even when no fees collected.
     */
    function collectFees() external nonReentrant {
        _askFund();
    }

    /**
     * @dev Collecting generated fees, stake the main token by calling 'stake' and increase the rewards for stakers by calling '_fund'
     * 
     * NOTE Goes through even when no fees collected.
     */
    function _askFund() internal {
        IFeeSource(feeSourceAdr).autoCollect();
    } 

    /**
     * @dev Returns the amount of fees that can be collected by the 'feeSourceAdr'
     * 
     * @return uint amount of fees
     */
    function _getAskFund() internal view returns(uint) {
        return IFeeSource(feeSourceAdr).getAutoCollectAmount(address(this));
    }

    /**
     * @dev Increase rewards by transfer staked token from the message sender and also calculate 'msg.value' in and call '_fund'
     * 
     * @param amountERC amount of staked token to add to the rewards
     * 
     * NOTE The msg.sender have to pay for any increase.
     */
    function fund(uint amountERC) external nonReentrant {
        restERC += amountERC;

        IERC20(rewardTokenAdr).safeTransferFrom(msg.sender, address(this), amountERC);
        emit FundsReceived(msg.sender, amountERC);

    }

    /**
     * @dev Increase 'restERC' by the given amount and emit an event with the sender and the amount.
     *
     * @param amountERC The amount of ERC tokens to add to 'restERC'.
     * 
     * NOTE Only the 'feeSourceAdr' can call this function.
     */
    function fundByFeeCollector(uint amountERC) external {
        require(msg.sender == feeSourceAdr, "RevenueStaking: Only the 'feeSourceAdr' can call this function.");
        restERC += amountERC;
        emit FundsReceived(feeSourceAdr, amountERC);
    }

    /**
     * @dev See '_fundCalc'
     * 
     */
    function fundCalc() external nonReentrant {
        _fundCalc();
    }

    function _calcCPSE() internal view returns(uint) {
        if (totalShares > 0) {
            uint currentBlock = block.number;
            uint happendBlocks = currentBlock - lastCalculationBlock;

            //if not used over a year -> all rewards getting calculated
            happendBlocks = blocksPerYear >= happendBlocks ? happendBlocks : blocksPerYear;

            uint tempRestERC = restERC + _getAskFund();

            uint rewardsPerBlock = tempRestERC / blocksPerYear;

            uint toReward = rewardsPerBlock * happendBlocks;

            uint tClaimablePerShareERC = toReward / totalShares;

            return tClaimablePerShareERC + claimablePerShareERC;
        }
        return claimablePerShareERC;
    }

    /**
     * @dev Increase 'claimablePerShareERC' depending on 'restERC' and 'happendBlocks' and 'totalShares'
     * 
     */
    function _fundCalc() internal {
        if (totalShares > 0) {
            uint currentBlock = block.number;
            uint happendBlocks = currentBlock - lastCalculationBlock;

            //if not used over a year -> all rewards getting calculated
            happendBlocks = blocksPerYear >= happendBlocks ? happendBlocks : blocksPerYear;

            uint rewardsPerBlock = restERC / blocksPerYear;

            uint toReward = rewardsPerBlock * happendBlocks;

            uint restRewardsPerBlock = restERC - toReward;

            uint tClaimablePerShareERC = toReward / totalShares;
            uint restClaimable = toReward - tClaimablePerShareERC * totalShares;

            restERC = restRewardsPerBlock + restClaimable;

            claimablePerShareERC += tClaimablePerShareERC;

            lastCalculationBlock = currentBlock;
        }
    }

    /**
     * @dev Returns the claimable staked token amount (check: NOTE) of given address
     * 
     * @param account address to check
     * 
     * NOTE Calculating in potential claimable fees by '_askfund'.
     */
    function claimable(address account) public view returns(uint, uint) {
        uint tempERC = (_calcCPSE() - stakes[account].claimablePerShareEntryERC) * stakes[account].shares + stakes[account].unclaimedERC;
        (, uint tempETH) = _claimable(account);
        return (tempERC, tempETH);
    }

    // function claimable(address account) public view returns(uint) {
    //     uint tempERC = (_calcCPSE() - stakes[account].claimablePerShareEntryERC) * stakes[account].shares + stakes[account].unclaimedERC;
    //     return tempERC;
    // }

    /**
     * @dev Same as 'claimable' but with no external contract call.
     * 
     * @param account address to check
     * 
     * NOTE Not calculating in potential claimable fees by '_askfund', because it is only used after '_askFund'.
     */
    function _claimable(address account) internal view returns(uint, uint) {
        return 
            ((claimablePerShareERC - stakes[account].claimablePerShareEntryERC) * stakes[account].shares + stakes[account].unclaimedERC, 
            (claimablePerShareETH - stakes[account].claimablePerShareEntryETH) * stakes[account].shares + stakes[account].unclaimedETH);
    }

    /**
     * @dev Updates the 'unclaimedETH' and 'unclaimedERC' amounts for an address calculated by the unclaimed rewards from the claimPerShare.
     *      Also set the 'claimablePerShareEntryETH' and 'claimablePerShareEntryERC' to the current global values.     * 
     * 
     * @param account address to check
     * 
     * NOTE Is called in 'claim', 'stake' and 'withdraw'.
     */
    function _updateClaimable(address account) internal returns(uint amountERC, uint amountETH) {
        (amountERC, amountETH) = _claimable(account);
        // claimable counts unclaimed in
        stakes[account].unclaimedERC = amountERC; 
        stakes[account].unclaimedETH = amountETH;
        stakes[account].claimablePerShareEntryERC = claimablePerShareERC;
        stakes[account].claimablePerShareEntryETH = claimablePerShareETH;
    }

    /**
     * @dev send rewards
     * 
     * @param account address of receiver
     * @param rewardERC amount of reward token to send
     * @param stakesERC amount of staked token to send
     * 
     * NOTE Is called by 'claim', 'stake' and 'withdraw'.
     */
    function _send(address account, uint rewardERC, uint rewardETH, uint stakesERC) internal {
        if (rewardERC > 0){
            IERC20(rewardTokenAdr).safeTransfer(account, rewardERC);
        }
        if (stakesERC > 0){
            IERC20(stakedTokenAdr).safeTransfer(account, stakesERC);
        }
        if (rewardETH > 0){
            (bool success, ) = payable(account).call{value: rewardETH}("");
            require(success, "RevenueStaking: Failed to send ETH");
        }
    }

    /**
     * @dev Updates the ''unclaimedERC' amounts for an address calculated by the unclaimed rewards from the claimPerShare.
     *      Also set the 'claimablePerShareEntryETH' and 'claimablePerShareEntryERC' to the current global values.     * 
     * 
     * @param account address to check
     * 
     * NOTE Is called in 'claim', 'stake' and 'withdraw'.
     */
    function _claimLogic(address account) internal returns (uint toSendERC, uint toSendETH) {
        (toSendERC, toSendETH) = _updateClaimable(account);

        stakes[account].unclaimedERC = 0;
        stakes[account].unclaimedETH = 0;
    }

    /**
     * @dev Claiming rewards by sending the staked token to the sender.
     */
    function claim() external nonReentrant {
        _askFund();
        _fundCalc();

        address account = msg.sender;

        (uint toSendERC, uint toSendETH) = _claimLogic(account);

        _send(account, toSendERC, toSendETH, 0);

        emit RewardReleased(account, toSendERC);
    }

    /**
     * @dev Staking the main token by transferring the amount to the contract and increasing the shares.
     * 
     * @param amount The amount of main token to stake.
     */
    function stake(uint amount) external nonReentrant {
        require(amount >= SHARE_DENOMINATOR, "RevenueStaking: Amount too small to stake.");
        _askFund();
        _fundCalc();

        if (totalShares == 0) {
            lastCalculationBlock = block.number;
        }

        address account = msg.sender;

        _updateClaimable(account);

        uint shares = amount / SHARE_DENOMINATOR;
        stakes[account].shares += shares;
        totalShares += shares;

        uint restFreeAmount = shares * SHARE_DENOMINATOR;
        IERC20(stakedTokenAdr).safeTransferFrom(account, address(this), restFreeAmount);

        emit StakeAdded(account, restFreeAmount);
    }

    /**
     * @dev Withdrawing the staked token by sending the shares back to the sender and the rest of the staked token to the sender.
     */
    function withdraw() external nonReentrant{
        address account = msg.sender;
        require(stakes[account].shares > 0, "RevenueStaking: You have no stakes.");

        _askFund();
        _fundCalc();
        
        uint toSendShares = stakes[account].shares * SHARE_DENOMINATOR;

        (uint toSendERC, uint toSendETH) = _claimLogic(account);

        totalShares -= stakes[account].shares;
        stakes[account].shares = 0;

        _send(account, toSendERC, toSendETH, toSendShares);

        emit StakeRemoved(account, toSendShares);
        emit RewardReleased(account, toSendERC);
    }

    /**
     * @dev Emergency withdrawal of the staked token by sending the shares back to the sender.
     * 
     * WARNING No rewards are claimed.
     */
    function emergencyWithdraw() external nonReentrant {
        address account = msg.sender;

        uint toSendShares = stakes[account].shares * SHARE_DENOMINATOR;

        totalShares -= stakes[account].shares;
        stakes[account].shares = 0;

        _send(account, 0, 0, toSendShares);

        emit StakeRemoved(account, toSendShares);
        emit RewardReleased(account, 0);
    }

    /**
     * @dev Removing the remaining rewards by sending them to the given address.
     * 
     * @param to The address to send the remaining rewards to.
     */
    function removeRewards(address to) external onlyOwner {
        _askFund();
        _fundCalc();

        IERC20(stakedTokenAdr).transfer(to, restERC);
    }

    /**
     * @dev Receiving ETH and increasing the rewards for stakers.
     */
    receive() external payable {
        uint total = msg.value + restETH;
        if (totalShares > 0) {
            uint rewards = total / totalShares;
            claimablePerShareETH += rewards;
            restETH = total - rewards * totalShares;
        } else {
            restETH += total;
        }
    }
}