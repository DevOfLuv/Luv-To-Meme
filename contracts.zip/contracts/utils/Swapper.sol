//SPDX-License-Identifier: MIT
pragma solidity >=0.8.20;

import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {IUniswapV2Router02} from "../interfaces/IUniswapV2Router02.sol";
import {IUniswapV2Factory} from "../interfaces/IUniswapV2Factory.sol";
import {OwnableHandshake} from "./OwnableHandshake.sol";
import {IMainToken} from "../interfaces/IMainToken.sol";
import {ITokenFactoryBase} from "../interfaces/ITokenFactoryBase.sol";
import {ISideToken_ERC20} from "../interfaces/ISideToken_ERC20.sol";

import "hardhat/console.sol";


contract Swapper is ReentrancyGuard, OwnableHandshake {
    using SafeERC20 for IERC20;

    struct swapParams {
        string refId; 
        address router0; 
        address router1; 
        uint amountIn;
        uint minAmountOut;
    }

    bool public tradeState;

    bool public openMode;

    uint public feeNominatorToken = 200;
    uint public feeNominatorWhithRef = 100;
    uint public feeNominatorWhithoutRef = 200;
    uint public immutable FEE_DENOMINATOR;

    address public mainToken;
    address public defaultRefReceiver;

    mapping(address => uint) public lastTransaction;

    mapping(address => bool) public whitelisted;
    mapping(string => address) public refIdToAddress;
    mapping(address => string) public addressToRefId;

    mapping(address => mapping(string => bool)) public refIdUsed;

    event ChangedFeeNominatorToken(uint oldFeeNominator, uint newFeeNominator);
    event ChangedFeeNominatorWhithRef(uint oldFeeNominator, uint newFeeNominator);
    event ChangedFeeNominatorWhithoutRef(uint oldFeeNominator, uint newFeeNominator);
    event ChangedDefaultRefReceiver(address oldDefaultRefReceiver, address newDefaultRefReceiver);
    event ChangedUnlimitedAccount(address account, bool unlimited);
    event RefReceived(address indexed refReceiver, uint amount);
    event RefIdAdded(address indexed user, string refId);
    event RefIdRemoved(address indexed user);

    modifier trade() {
        tradeState = true;
        _;
        tradeState = false;
    }

    /**
     * @dev Limits the number of transactions per block for a given account.
     * @param account The address of the account to limit interactions for.
     */
    modifier limitInteractions(address account) {
        require(lastTransaction[account] < block.number, "Swapper: Only one transaction per block.");
        lastTransaction[account] = lastTransaction[account] == 1 ? 1 : block.number;
        _;
    }

    /**
     * @dev Initializes the Swapper contract.
     * @param mainToken_ The address of the main token.
     */ 
    constructor(address mainToken_) OwnableHandshake(msg.sender) {
        mainToken = mainToken_;
        defaultRefReceiver = IMainToken(mainToken).feeAccount();
        FEE_DENOMINATOR = IMainToken(mainToken).FEE_DENOMINATOR();
    }


    /**
     * @dev Changes the feeNominatorToken.
     * @param newFeeNominator The new feeNominatorToken.
     */
    function changeFeeNominatorToken(uint newFeeNominator) external onlyOwner {
        emit ChangedFeeNominatorToken(feeNominatorToken, newFeeNominator);
        feeNominatorToken = newFeeNominator;
    }

    /**
     * @dev Sets the unlimited status for a given account.
     * @param account The address of the account to set the unlimited status for.
     * @param unlimited The boolean value to set the unlimited status to.
     */
    function setUnlimitedAccount(address account, bool unlimited) external onlyOwner {
        emit ChangedUnlimitedAccount(account, unlimited);
        lastTransaction[account] = unlimited ? 1 : block.number;
    }

    /**
     * @dev Changes the default reference receiver.
     * @param newDefaultRefReceiver The address of the new default reference receiver.
     */
    function changeDefaultRefReceiver(address newDefaultRefReceiver) external onlyOwner {
        emit ChangedDefaultRefReceiver(defaultRefReceiver, newDefaultRefReceiver);
        defaultRefReceiver = newDefaultRefReceiver;
    }

    /**
     * @dev Changes the feeNominatorWhithoutRef.
     * @param newFeeNominator The new feeNominatorWhithoutRef.
     */
    function changeFeeNominatorWhithoutRef(uint newFeeNominator) external onlyOwner {
        require(IMainToken(mainToken).feeNominator() <= newFeeNominator, "Swapper: Fee is meant to be less than the main token's feeNominator");
        emit ChangedFeeNominatorWhithoutRef(feeNominatorWhithoutRef, newFeeNominator);
        feeNominatorWhithoutRef = newFeeNominator;
    }

    /**
     * @dev Changes the feeNominatorWhithRef.
     * @param newFeeNominator The new feeNominatorWhithRef.
     */
    function changeFeeNominatorWhithRef(uint newFeeNominator) external onlyOwner {
        require(IMainToken(mainToken).feeNominator() <= newFeeNominator, "Swapper: Fee is meant to be less than the main token's feeNominator");
        emit ChangedFeeNominatorWhithRef(feeNominatorWhithRef, newFeeNominator);
        feeNominatorWhithRef = newFeeNominator;
    }

    /**
     * @dev Adds a list of addresses to the whitelist.
     * @param addresses The addresses to add to the whitelist.
     */
    function addWhitelist(address[] memory addresses) external onlyOwner {
        for (uint i = 0; i < addresses.length; i++) {
            whitelisted[addresses[i]] = true;
        }
    }

    /**
     * @dev Returns the reference ID for a given user.
     * @param user The address of the user to get the reference ID for.
     * @return The reference ID for the given user.
     */
    function getRefId(address user) external view returns (string memory) {
        return addressToRefId[user];
    }

    /**
     * @dev Removes the reference ID for a given user.
     * @param user The address of the user to remove the reference ID for.
     */
    function _removeRefId(address user) internal {
        string memory refIdHash = addressToRefId[user];
        refIdToAddress[refIdHash] = address(0);
        refIdUsed[user][refIdHash] = false;
        addressToRefId[user] = "";
        emit RefIdRemoved(user);
    }

    /**
     * @dev Adds a reference ID for a given user.
     * @param user The address of the user to add the reference ID for.
     * @param refIdHash The reference ID to add for the given user.
     */
    function _addRefId(address user, string memory refIdHash) internal {
        refIdToAddress[refIdHash] = user;
        refIdUsed[user][refIdHash] = true;
        addressToRefId[user] = refIdHash;
        emit RefIdAdded(user, refIdHash);
    }

    /**
     * @dev Creates a reference ID for the sender.
     * @param refId The reference ID to create.
     */
    function createRefId(string calldata refId) external {
        require(whitelisted[msg.sender] || openMode, "Swapper: Sender is not whitelisted");
        require(bytes(refId).length > 0, "Swapper: RefId cannot be empty");
        require(refIdToAddress[refId] == address(0), "Swapper: RefId already exists");

        _removeRefId(msg.sender);
        _addRefId(msg.sender, refId);
    }

    /**
     * @dev Creates a reference ID for a given user.
     * @param forAdr The address of the user to create the reference ID for.
     * @param refId The reference ID to create.
     */
    function createRefIdForUser(address forAdr, string calldata refId) external onlyOwner {
        require(bytes(refId).length > 0, "Swapper: RefId cannot be empty");
        require(refIdToAddress[refId] == address(0), "Swapper: RefId already exists");

        _removeRefId(forAdr);
        _addRefId(forAdr, refId);
    }

    /**
     * @dev Removes the reference ID for a given user.
     * @param user The address of the user to remove the reference ID for.
     */
    function removeRefId(address user) external {
        require(msg.sender == owner() || user == msg.sender, "Swapper: only owner or given user can remove refId");
        _removeRefId(user);
    }

    /**
     * @dev Removes the reference ID for a given user and whitelists them.
     * @param user The address of the user to remove the reference ID for and whitelist.
     */
    function removeRefAndWhitelist(address user) external {
        require(whitelisted[user], "Swapper: given user is not whitelisted nor you are the owner");
        require(msg.sender == owner() || user == msg.sender, "Swapper: only owner or given user can remove refId and whitelist");
        whitelisted[user] = false;
        _removeRefId(user);
    }

    /**
     * @dev Swaps in tokens to the contract.
     * @param refId The reference ID to use.
     * @param path The path of the swap.
     * @param minAmountOut The minimum amount out.
     */
    function swapIn(string calldata refId, address[] memory path, uint256 minAmountOut) external payable trade nonReentrant limitInteractions(msg.sender) {
        address refReceiver = refIdToAddress[refId];

        address token = path[path.length - 1];
        address router = ITokenFactoryBase(ISideToken_ERC20(token).tokenFactory()).uniswapRouterAdr();

        uint feeNominator = feeNominatorWhithRef;

        if (refReceiver == address(0)) {
            refReceiver = defaultRefReceiver;
            feeNominator = feeNominatorWhithoutRef;
        }

        uint fee = msg.value * feeNominator / FEE_DENOMINATOR;

        IUniswapV2Router02(router).swapExactETHForTokensSupportingFeeOnTransferTokens{value: msg.value - fee}
        (
            minAmountOut,
            path,
            msg.sender,
            block.timestamp
        );

        payable(refReceiver).transfer(fee);

        emit RefReceived(refReceiver, fee);
    }

    /**
     * @dev Swaps out tokens from the contract.
     * @param refId The reference ID to use.
     * @param path The path of the swap.
     * @param amountIn The amount in.
     * @param minAmountOut The minimum amount out.
     */
    function swapOut(string calldata refId, address[] memory path, uint amountIn, uint256 minAmountOut) external trade nonReentrant limitInteractions(msg.sender){
        address refReceiver = refIdToAddress[refId];   

        address token = path[0];
        address router = ITokenFactoryBase(ISideToken_ERC20(token).tokenFactory()).uniswapRouterAdr();
        uint feeNominator = feeNominatorWhithRef;

        if (refReceiver == address(0)) {
            refReceiver = defaultRefReceiver;
            feeNominator = feeNominatorWhithoutRef;
        }

        uint balanceBefore = address(this).balance;
        uint balanceBeforeToken = IERC20(token).balanceOf(address(this));

        IERC20(token).transferFrom(msg.sender, address(this), amountIn);

        uint balanceAfterToken = IERC20(token).balanceOf(address(this));
        uint amountInAfter = balanceAfterToken - balanceBeforeToken;

        IERC20(token).approve(router, amountInAfter);

        IUniswapV2Router02(router).swapExactTokensForETHSupportingFeeOnTransferTokens
        (
            amountInAfter, 
            0, 
            path, 
            address(this), 
            block.timestamp
        );

        uint balanceAfter = address(this).balance;
        uint diff = balanceAfter - balanceBefore;

        uint fee = diff * feeNominator / FEE_DENOMINATOR;

        uint afterFee = diff - fee;
        require(afterFee >= minAmountOut, "Swapper: Insufficient amount out.");

        payable(refReceiver).transfer(fee);
        payable(msg.sender).transfer(afterFee);

        emit RefReceived(refReceiver, fee);
    }

    function swapOutERC(address[] memory path, uint amountIn, uint256 minAmountOut) external nonReentrant limitInteractions(msg.sender) {
        address token = path[0];
        address router = ITokenFactoryBase(ISideToken_ERC20(token).tokenFactory()).uniswapRouterAdr();

        uint balanceBefore = IERC20(token).balanceOf(address(this));
        IERC20(token).safeTransferFrom(msg.sender, address(this), amountIn);
        uint balanceAfter = IERC20(token).balanceOf(address(this));
        uint amountInAfter = balanceAfter - balanceBefore;
        require(amountInAfter > 0, "Swapper: Amount in is 0 after transfer");

        IERC20(token).approve(router, amountIn);

        IUniswapV2Router02(router).swapExactTokensForTokensSupportingFeeOnTransferTokens
        (
            amountIn,
            minAmountOut,
            path,
            msg.sender,
            block.timestamp
        );
    }

    function swapInERC(address[] memory path, uint amountIn, uint256 minAmountOut) external nonReentrant limitInteractions(msg.sender) {
        address tokenIn = path[0];
        address tokenOut = path[path.length - 1];
        address router = ITokenFactoryBase(ISideToken_ERC20(tokenOut).tokenFactory()).uniswapRouterAdr();

        uint balanceBefore = IERC20(tokenIn).balanceOf(address(this));
        IERC20(tokenIn).safeTransferFrom(msg.sender, address(this), amountIn);
        uint balanceAfter = IERC20(tokenIn).balanceOf(address(this));
        uint amountInAfter = balanceAfter - balanceBefore;
        require(amountInAfter > 0, "Swapper: Amount in is 0 after transfer");

        IERC20(tokenIn).approve(router, amountInAfter);

        IUniswapV2Router02(router).swapExactTokensForTokensSupportingFeeOnTransferTokens
        (
            amountInAfter,
            minAmountOut,
            path,
            msg.sender,
            block.timestamp
        );
    }

    /**
     * @dev Receives ETH.
     */
    receive() external payable {}
}
