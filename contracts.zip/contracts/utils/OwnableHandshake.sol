// SPDX-License-Identifier: MIT
// luv to meme
// OpenZeppelin Contracts (last updated v5.0.0) (access/Ownable.sol)

pragma solidity ^0.8.20;

import {Context} from "@openzeppelin/contracts/utils/Context.sol";


/**
 * @dev Contract module which provides a basic access control mechanism, where
 * there is an account (an owner) that can be granted exclusive access to
 * specific functions.
 *
 * The initial owner is set to the address provided by the deployer. This can
 * later be changed with {transferOwnership}.
 *
 * This module is used through inheritance. It will make available the modifier
 * `onlyOwner`, which can be applied to your functions to restrict their use to
 * the owner.
 * 
 * @notice Changed: implemented a handshake to transfer ownership, to make sure the new
 *         owner is accessable.
 */
abstract contract OwnableHandshake is Context {
    address private _owner;
    address private _submittedOwner;

    bool firstOverTake;

    /**
     * @dev The caller account is not authorized to perform an operation.
     */
    error OwnableUnauthorizedAccount(address account);

    /**
     * @dev The owner is not a valid owner account. (eg. `address(0)`)
     */
    error OwnableInvalidOwner(address owner);

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    event OwnershiptTransferSubmitted(address ownerSubmitted);

    event OwnershipTransferAccepted();

    /**
     * @dev Initializes the contract setting the address provided by the deployer as the initial owner.
     */
    constructor(address initialOwner) {
        if (initialOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(initialOwner);
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        _checkOwner();
        _;
    }

    /**
     * @dev Returns the address of the current owner.
     */
    function owner() public view virtual returns (address) {
        return _owner;
    }

    /**
     * @dev Throws if the sender is not the owner.
     */
    function _checkOwner() internal view virtual {
        if (owner() != _msgSender()) {
            revert OwnableUnauthorizedAccount(_msgSender());
        }
    }

    /**
     * @dev Leaves the contract without owner. It will not be possible to call
     * `onlyOwner` functions. Can only be called by the current owner.
     *
     * NOTE: Renouncing ownership will leave the contract without an owner,
     * thereby disabling any functionality that is only available to the owner.
     */
    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    /**
     * @dev Changes the ownership of the contract after deployment.
     *
     * @param newOwner The new owner address to set.
     * 
     * NOTE: This function can only be called once to prevent reentrancy and simplify the deployment process.
     */
    function changeOwnershipAfterDeployment(address newOwner) external virtual onlyOwner {
        require(!firstOverTake);
        _transferOwnership(newOwner);
        firstOverTake = true;
    }

    /**
     * @dev Submit a transfer of the ownership of the contract to a new account (`newOwner`).
     * Can only be called by the current owner.
     * 
     * NOTE: The 'newOwner' has to call 'acceptOwnership'.
     *       If 'submitTransferOwnership' is called before the old 'newOwner' accepted the ownership
     *       the new 'newOwner' can accept the old one not anymore.
     */
    function submitTransferOwnership(address newOwner) public virtual onlyOwner {
        if (newOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _submittedOwner = newOwner;
        emit OwnershiptTransferSubmitted(_submittedOwner);
    }

    /**
     * @dev Accepts the ownership transfer.
     * 
     * NOTE: The 'newOwner' has to call 'acceptOwnership'.
     *       If 'submitTransferOwnership' is called before the old 'newOwner' accepted the ownership
     *       the new 'newOwner' can accept the old one not anymore.
     */
    function acceptOwnership() public virtual {
        require(msg.sender == _submittedOwner, "OwnableHandshake: Only the 'submittedOwner' can accept the ownership.");
        _transferOwnership(_submittedOwner);
        emit OwnershipTransferAccepted();
    }

    function submittedOwner() public view returns (address) {
        return _submittedOwner;
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Internal function without access restriction.
     */
    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}