//SPDX-License-Identifier: MIT
pragma solidity >=0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {OwnableHandshake} from "./OwnableHandshake.sol";
import {IUniswapV2Router02} from "../interfaces/IUniswapV2Router02.sol";
import {IStakingNFT} from "../interfaces/IStakingNFT.sol";
import {IMainToken} from "../interfaces/IMainToken.sol";


contract LuvBomb is OwnableHandshake {

    mapping(address => bool) public canSend;

    address public mainToken;
    address public stakingNFT;
    address public uniswapRouter;
    address public stakedToken;

    event SenderChanged(address indexed sender, bool state);
    event Convert(uint ethAmount, uint mainTokenAmount);

    constructor(address mainToken_, address stakingNFT_) OwnableHandshake(msg.sender) {
        mainToken = mainToken_;
        stakingNFT = stakingNFT_;
        uniswapRouter = IMainToken(mainToken_).UNISWAP_ROUTER();
        stakedToken = IStakingNFT(stakingNFT_).stakedTokenAddress();
    }

    /**
     * @dev Add or remove an address from the list of allowed senders.
     * 
     * @param sender_ The address to add to the list of allowed senders.
     */ 
    function changeSender(address sender_, bool state_) external onlyOwner {
        canSend[sender_] = state_;
        emit SenderChanged(sender_, state_);
    }
    
    /**
     * @dev Bomb the Luv.
     * 
     * @param to_ The address to send the Luv to.
     * @param amount_ The amount of Luv to send.
     */
    function bomb(address to_, uint amount_) external {
        _convert();
        require(canSend[msg.sender], "LuvBomb: You are not allowed to send");
        IERC20(stakedToken).transfer(to_, amount_);
    }

    function convert() external {
        _convert();
    }

    /**
     * @dev Swaps ETH to Luv, if there is any.
     */
    function _convert() internal {
        uint ethBalance = address(this).balance;

        if (ethBalance > 0) {
            address[] memory path = new address[](2);
            path[0] = IUniswapV2Router02(uniswapRouter).WETH();
            path[1] = mainToken;
            IUniswapV2Router02(uniswapRouter).swapExactETHForTokensSupportingFeeOnTransferTokens{value: ethBalance}(0, path, address(this), block.timestamp);
        }

        uint mainBalance = IERC20(mainToken).balanceOf(address(this));

        if (mainBalance > 0) {
            IERC20(mainToken).approve(stakingNFT, mainBalance);
            IStakingNFT(stakingNFT).stake(mainBalance);
        }
        emit Convert(ethBalance, mainBalance);
    }

}