// // SPDX-License-Identifier: MIT
// pragma solidity >=0.5.16;

// import '@uniswap/v2-core/contracts/interfaces/IUniswapV2Factory.sol';
// import './UniswapV2Pair.sol';

// contract UniswapV2Factory is IUniswapV2Factory {
//     address public feeTo;
//     address public feeToSetter;
//     address public requiredToken;
//     address public collector;

//     bytes32 public constant INIT_CODE_PAIR_HASH = keccak256(abi.encodePacked(type(UniswapV2Pair).creationCode));

//     mapping(address => mapping(address => address)) public getPair;
//     //changed
//     mapping(address => bool) public isPair;

//     address[] public allPairs;

//     event PairCreated(address indexed token0, address indexed token1, address pair, uint);

//     constructor(address _feeToSetter, address _reqToken, address _collector) public {
//         feeToSetter = _feeToSetter;
//         requiredToken = _reqToken;
//         collector = _collector;
//     }

//     function allPairsLength() external view returns (uint) {
//         return allPairs.length;
//     }

//     function createPair(address tokenA, address tokenB) external returns (address pair) {
//         bool mintable = true;
//         require(
//             tokenA == requiredToken ||
//             tokenB == requiredToken,
//             "AuctumSwap: One token of he pair needs to be STX."
//         );

//         if (allPairs.length < 3) {
//             require(msg.sender == collector, "AuctumSwap: Only the Collector can create first pairs.");
//             mintable = false;
//         }

//         return _createPair(tokenA, tokenB, mintable);
//     }

//     function _createPair(address tokenA, address tokenB, bool _mintable) internal returns (address pair) {
       
//         require(tokenA != tokenB, 'UniswapV2: IDENTICAL_ADDRESSES');
//         (address token0, address token1) = tokenA < tokenB ? (tokenA, tokenB) : (tokenB, tokenA);
//         require(token0 != address(0), 'UniswapV2: ZERO_ADDRESS');
//         require(getPair[token0][token1] == address(0), 'UniswapV2: PAIR_EXISTS'); // single check is sufficient
//         bytes memory bytecode = type(UniswapV2Pair).creationCode;
//         bytes32 salt = keccak256(abi.encodePacked(token0, token1));
//         assembly {
//             pair := create2(0, add(bytecode, 32), mload(bytecode), salt)
//         }
//         IUniswapV2Pair(pair).initialize(token0, token1, _mintable, requiredToken);
//         getPair[token0][token1] = pair;
//         getPair[token1][token0] = pair; // populate mapping in the reverse direction
//         //changed
//         isPair[pair] = true;

//         allPairs.push(pair);
//         emit PairCreated(token0, token1, pair, allPairs.length);
//     }

//     function setFeeTo(address _feeTo) external {
//         require(msg.sender == feeToSetter, 'UniswapV2: FORBIDDEN');
//         feeTo = _feeTo;
//     }

//     function setFeeToSetter(address _feeToSetter) external {
//         require(msg.sender == feeToSetter, 'UniswapV2: FORBIDDEN');
//         feeToSetter = _feeToSetter;
//     }
// }
