// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import {SideToken_ERC20} from "./SideToken_ERC20.sol";
import {IUniswapV2Factory} from "./interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "./interfaces/IUniswapV2Router02.sol";
import {IMainToken} from "./interfaces/IMainToken.sol";
import {ISideToken_CLOG} from "./interfaces/ISideToken_CLOG.sol";

import {TokenFactoryBase} from "./TokenFactoryBase.sol";

contract TokenFactory01 is TokenFactoryBase {

    constructor(address initialOwner_) TokenFactoryBase(initialOwner_){}

    /**
     * @dev Creates a new ERC20 token with the specified parameters and adds liquidity for it. 
     * This function facilitates the creation and initial setup of a new token, including
     * minting, liquidity provision, optional first buy, and tracking the new token.
     * 
     * @param name_ The name of the new ERC20 token.
     * @param symbol_ The symbol of the new ERC20 token.
     * @param decimals_ The number of decimals the token uses.
     * @param totalSupply_ The initial total supply of the new token.
     * @param mediaAccount_ The address associated with media accounts or promotion.
     * @param mainTokenAmount_ The amount of main tokens to use for liquidity.
     * @param salt_ A unique salt value used for deploying the new token.
     * @param firstBuyAmount_ The amount for the first buy to be triggered. (optional)
     * @param metadata_ The metadata associated with the new token, containing additional configuration.
     * 
     * NOTE: This function creates a new `SideToken_ERC20` instance and mints main tokens for it,
     * setting up initial liquidity on Uniswap. It also updates internal tracking for created tokens.
     */ 
    function createERC20Token(
        string memory name_, string memory symbol_, uint8 decimals_, uint totalSupply_, address mediaAccount_, uint mainTokenAmount_, uint salt_, uint firstBuyAmount_,
        SideToken_ERC20.Metadata memory metadata_
    ) external {
        SideToken_ERC20 newToken = new SideToken_ERC20(name_, symbol_, decimals_, totalSupply_, mediaAccount_, salt_, metadata_, mainTokenAdr);

        IMainToken(mainTokenAdr).factoryMint(mainTokenAmount_, address(newToken), firstBuyAmount_, msg.sender);

        _setValues(address(newToken), TokenType.ERC20);
    }

}